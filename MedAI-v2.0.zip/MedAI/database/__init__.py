"""
Database Manager — SQLite backend for MedAI
Handles users, chat sessions, messages, and downloaded data tracking.
"""
import sqlite3
import json
import hashlib
import datetime
from pathlib import Path
from typing import Optional
from config import DATABASE_PATH


def _connect():
    conn = sqlite3.connect(str(DATABASE_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    """Create all tables if they don't exist."""
    conn = _connect()
    c = conn.cursor()
    c.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            google_id       TEXT UNIQUE NOT NULL,
            email           TEXT UNIQUE NOT NULL,
            display_name    TEXT NOT NULL DEFAULT '',
            avatar_url      TEXT DEFAULT '',
            created_at      TEXT NOT NULL DEFAULT (datetime('now')),
            last_login      TEXT NOT NULL DEFAULT (datetime('now')),
            preferences     TEXT DEFAULT '{}'
        );

        CREATE TABLE IF NOT EXISTS chat_sessions (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id         INTEGER NOT NULL,
            title           TEXT NOT NULL DEFAULT 'New Chat',
            created_at      TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at      TEXT NOT NULL DEFAULT (datetime('now')),
            is_archived     INTEGER DEFAULT 0,
            metadata        TEXT DEFAULT '{}',
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS messages (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id      INTEGER NOT NULL,
            role            TEXT NOT NULL CHECK(role IN ('user','assistant','system')),
            content         TEXT NOT NULL,
            timestamp       TEXT NOT NULL DEFAULT (datetime('now')),
            tokens_used     INTEGER DEFAULT 0,
            model_used      TEXT DEFAULT '',
            FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS downloaded_fields (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id         INTEGER NOT NULL,
            field_key       TEXT NOT NULL,
            field_name      TEXT NOT NULL,
            downloaded_at   TEXT NOT NULL DEFAULT (datetime('now')),
            file_path       TEXT NOT NULL,
            size_bytes      INTEGER DEFAULT 0,
            version         TEXT DEFAULT '1.0',
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE(user_id, field_key)
        );

        CREATE TABLE IF NOT EXISTS app_settings (
            key             TEXT PRIMARY KEY,
            value           TEXT NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_sessions_user ON chat_sessions(user_id);
        CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id);
        CREATE INDEX IF NOT EXISTS idx_downloaded_user ON downloaded_fields(user_id);
    """)
    conn.commit()
    conn.close()


# ─── User Operations ──────────────────────────────────────────────────────────

def upsert_user(google_id: str, email: str, display_name: str, avatar_url: str = "") -> dict:
    conn = _connect()
    c = conn.cursor()
    c.execute(
        """INSERT INTO users (google_id, email, display_name, avatar_url)
           VALUES (?, ?, ?, ?)
           ON CONFLICT(google_id) DO UPDATE SET
               email=excluded.email,
               display_name=excluded.display_name,
               avatar_url=excluded.avatar_url,
               last_login=datetime('now')""",
        (google_id, email, display_name, avatar_url),
    )
    conn.commit()
    user = dict(c.execute("SELECT * FROM users WHERE google_id=?", (google_id,)).fetchone())
    conn.close()
    return user


def get_user_by_email(email: str) -> Optional[dict]:
    conn = _connect()
    row = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_user_by_id(user_id: int) -> Optional[dict]:
    conn = _connect()
    row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def update_user_preferences(user_id: int, prefs: dict):
    conn = _connect()
    conn.execute("UPDATE users SET preferences=? WHERE id=?", (json.dumps(prefs), user_id))
    conn.commit()
    conn.close()


# ─── Chat Session Operations ─────────────────────────────────────────────────

def create_session(user_id: int, title: str = "New Chat") -> int:
    conn = _connect()
    c = conn.cursor()
    c.execute("INSERT INTO chat_sessions (user_id, title) VALUES (?, ?)", (user_id, title))
    conn.commit()
    sid = c.lastrowid
    conn.close()
    return sid


def get_user_sessions(user_id: int, include_archived: bool = False) -> list:
    conn = _connect()
    q = "SELECT * FROM chat_sessions WHERE user_id=?"
    params = [user_id]
    if not include_archived:
        q += " AND is_archived=0"
    q += " ORDER BY updated_at DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_session_title(session_id: int, title: str):
    conn = _connect()
    conn.execute(
        "UPDATE chat_sessions SET title=?, updated_at=datetime('now') WHERE id=?",
        (title, session_id),
    )
    conn.commit()
    conn.close()


def delete_session(session_id: int):
    conn = _connect()
    conn.execute("DELETE FROM chat_sessions WHERE id=?", (session_id,))
    conn.commit()
    conn.close()


def archive_session(session_id: int):
    conn = _connect()
    conn.execute("UPDATE chat_sessions SET is_archived=1 WHERE id=?", (session_id,))
    conn.commit()
    conn.close()


# ─── Message Operations ──────────────────────────────────────────────────────

def add_message(session_id: int, role: str, content: str, tokens: int = 0, model: str = "") -> int:
    conn = _connect()
    c = conn.cursor()
    c.execute(
        "INSERT INTO messages (session_id, role, content, tokens_used, model_used) VALUES (?,?,?,?,?)",
        (session_id, role, content, tokens, model),
    )
    conn.execute(
        "UPDATE chat_sessions SET updated_at=datetime('now') WHERE id=?", (session_id,)
    )
    conn.commit()
    mid = c.lastrowid
    conn.close()
    return mid


def get_session_messages(session_id: int, limit: int = 0) -> list:
    conn = _connect()
    q = "SELECT * FROM messages WHERE session_id=? ORDER BY timestamp ASC"
    if limit > 0:
        q += f" LIMIT {limit}"
    rows = conn.execute(q, (session_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_session_message_count(session_id: int) -> int:
    conn = _connect()
    row = conn.execute("SELECT COUNT(*) as cnt FROM messages WHERE session_id=?", (session_id,)).fetchone()
    conn.close()
    return row["cnt"]


# ─── Downloaded Fields ────────────────────────────────────────────────────────

def record_download(user_id: int, field_key: str, field_name: str, file_path: str, size_bytes: int):
    conn = _connect()
    conn.execute(
        """INSERT INTO downloaded_fields (user_id, field_key, field_name, file_path, size_bytes)
           VALUES (?,?,?,?,?)
           ON CONFLICT(user_id, field_key) DO UPDATE SET
               downloaded_at=datetime('now'), file_path=excluded.file_path, size_bytes=excluded.size_bytes""",
        (user_id, field_key, field_name, file_path, size_bytes),
    )
    conn.commit()
    conn.close()


def get_downloaded_fields(user_id: int) -> list:
    conn = _connect()
    rows = conn.execute("SELECT * FROM downloaded_fields WHERE user_id=?", (user_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def remove_download_record(user_id: int, field_key: str):
    conn = _connect()
    conn.execute("DELETE FROM downloaded_fields WHERE user_id=? AND field_key=?", (user_id, field_key))
    conn.commit()
    conn.close()


# ─── Settings ─────────────────────────────────────────────────────────────────

def get_setting(key: str, default: str = "") -> str:
    conn = _connect()
    row = conn.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else default


def set_setting(key: str, value: str):
    conn = _connect()
    conn.execute(
        "INSERT INTO app_settings (key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, value),
    )
    conn.commit()
    conn.close()


# ─── Search ───────────────────────────────────────────────────────────────────

def search_messages(user_id: int, query: str, limit: int = 50) -> list:
    conn = _connect()
    rows = conn.execute(
        """SELECT m.*, cs.title as session_title
           FROM messages m
           JOIN chat_sessions cs ON m.session_id = cs.id
           WHERE cs.user_id=? AND m.content LIKE ?
           ORDER BY m.timestamp DESC LIMIT ?""",
        (user_id, f"%{query}%", limit),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]
