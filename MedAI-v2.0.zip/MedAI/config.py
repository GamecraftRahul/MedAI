"""
MedAI Configuration
Central configuration for the Medical AI Application
"""
import os
import json
from pathlib import Path

# ─── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent.resolve()
DATA_DIR = BASE_DIR / "data"
MEDICAL_DATA_DIR = DATA_DIR / "medical_fields"
DB_DIR = DATA_DIR / "database"
AUTH_DIR = BASE_DIR / "auth"
ASSETS_DIR = BASE_DIR / "assets"
CACHE_DIR = DATA_DIR / "cache"

for d in [DATA_DIR, MEDICAL_DATA_DIR, DB_DIR, AUTH_DIR, ASSETS_DIR, CACHE_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ─── Database ─────────────────────────────────────────────────────────────────
DATABASE_PATH = DB_DIR / "medai.db"

# ─── Google OAuth ─────────────────────────────────────────────────────────────
GOOGLE_CLIENT_SECRETS = AUTH_DIR / "client_secret.json"
GOOGLE_TOKEN_DIR = AUTH_DIR / "tokens"
GOOGLE_TOKEN_DIR.mkdir(parents=True, exist_ok=True)
GOOGLE_SCOPES = [
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/userinfo.profile",
    "openid",
]
OAUTH_REDIRECT_PORT = 8491

# ─── Ollama ───────────────────────────────────────────────────────────────────
OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("MEDAI_MODEL", "llama3.1")
OLLAMA_FALLBACK_MODELS = ["llama3.1", "llama3", "mistral", "gemma2", "phi3"]
OLLAMA_TIMEOUT = 120

# ─── Application ──────────────────────────────────────────────────────────────
APP_NAME = "MedAI — Medical Intelligence Assistant"
APP_VERSION = "2.0.0"
APP_ICON = ASSETS_DIR / "icon.ico"
WINDOW_WIDTH = 1280
WINDOW_HEIGHT = 800
MIN_WIDTH = 960
MIN_HEIGHT = 640

# ─── Medical System Prompt ────────────────────────────────────────────────────
MEDICAL_SYSTEM_PROMPT = """You are MedAI, a highly knowledgeable Medical Intelligence Assistant.
Your expertise spans ALL areas of medicine and healthcare:

🏥 CLINICAL MEDICINE: Internal medicine, surgery, pediatrics, obstetrics, gynecology,
   psychiatry, neurology, cardiology, oncology, dermatology, ophthalmology,
   otolaryngology, urology, orthopedics, and all medical specialties.

🦠 MICROBIOLOGY: Bacteria, viruses, fungi, parasites, prions — their morphology,
   pathogenesis, transmission, diagnosis, treatment, and epidemiology.

🧬 DISEASES: Every known disease — infectious, genetic, autoimmune, degenerative,
   metabolic, neoplastic, congenital, environmental, occupational, and rare diseases.

💊 PHARMACOLOGY: Drug classes, mechanisms, indications, contraindications, side effects,
   interactions, pharmacokinetics, pharmacodynamics, and clinical therapeutics.

🔬 DIAGNOSTICS: Laboratory tests, imaging, pathology, molecular diagnostics,
   genetic testing, point-of-care testing, and clinical decision-making.

📋 PUBLIC HEALTH: Epidemiology, biostatistics, health policy, global health,
   preventive medicine, vaccination, sanitation, and disease surveillance.

🧪 MEDICAL RESEARCH: Clinical trials, evidence-based medicine, medical ethics,
   emerging therapies, biotechnology, and cutting-edge medical advances.

🩺 ANATOMY & PHYSIOLOGY: Human body systems, cellular biology, histology,
   embryology, biochemistry, and pathophysiology.

GUIDELINES:
1. Provide accurate, evidence-based medical information
2. Always note that your information is educational, NOT a substitute for professional medical advice
3. Cite relevant medical literature and guidelines when possible
4. Use clear language; explain complex terms
5. If asked about emergencies, always advise calling emergency services first
6. Be thorough but organized in your responses
7. When discussing treatments, mention both conventional and any evidence-based alternatives
8. Include relevant ICD codes, drug names (generic), and standard classifications where helpful

DISCLAIMER: Always remind users that this is an educational tool and they should
consult healthcare professionals for personal medical decisions."""

# ─── Medical Sub-Fields for Download ──────────────────────────────────────────
MEDICAL_SUBFIELDS = {
    "anatomy_physiology": {
        "name": "Anatomy & Physiology",
        "icon": "🫀",
        "description": "Human body systems, organs, tissues, cellular biology",
        "size_mb": 45,
    },
    "pharmacology": {
        "name": "Pharmacology & Drugs",
        "icon": "💊",
        "description": "Drug classes, mechanisms, interactions, dosages",
        "size_mb": 38,
    },
    "microbiology": {
        "name": "Microbiology & Infectious Disease",
        "icon": "🦠",
        "description": "Bacteria, viruses, fungi, parasites, infections",
        "size_mb": 42,
    },
    "pathology": {
        "name": "Pathology & Diseases",
        "icon": "🔬",
        "description": "Disease mechanisms, classification, diagnosis",
        "size_mb": 55,
    },
    "surgery": {
        "name": "Surgery & Procedures",
        "icon": "🏥",
        "description": "Surgical techniques, pre/post-operative care",
        "size_mb": 35,
    },
    "cardiology": {
        "name": "Cardiology",
        "icon": "❤️",
        "description": "Heart diseases, ECG, cardiac procedures",
        "size_mb": 30,
    },
    "neurology": {
        "name": "Neurology & Neuroscience",
        "icon": "🧠",
        "description": "Brain, nervous system, neurological disorders",
        "size_mb": 40,
    },
    "oncology": {
        "name": "Oncology & Cancer",
        "icon": "🎗️",
        "description": "Cancer types, staging, chemotherapy, immunotherapy",
        "size_mb": 48,
    },
    "pediatrics": {
        "name": "Pediatrics",
        "icon": "👶",
        "description": "Child health, development, pediatric diseases",
        "size_mb": 32,
    },
    "psychiatry": {
        "name": "Psychiatry & Psychology",
        "icon": "🧘",
        "description": "Mental health disorders, treatments, therapies",
        "size_mb": 28,
    },
    "emergency_medicine": {
        "name": "Emergency Medicine",
        "icon": "🚑",
        "description": "Trauma, acute care, emergency protocols",
        "size_mb": 25,
    },
    "dermatology": {
        "name": "Dermatology",
        "icon": "🩹",
        "description": "Skin conditions, treatments, cosmetic dermatology",
        "size_mb": 22,
    },
    "orthopedics": {
        "name": "Orthopedics",
        "icon": "🦴",
        "description": "Bones, joints, musculoskeletal disorders",
        "size_mb": 27,
    },
    "endocrinology": {
        "name": "Endocrinology",
        "icon": "⚗️",
        "description": "Hormones, diabetes, thyroid, metabolic disorders",
        "size_mb": 24,
    },
    "immunology": {
        "name": "Immunology & Allergy",
        "icon": "🛡️",
        "description": "Immune system, autoimmune diseases, allergies",
        "size_mb": 26,
    },
    "public_health": {
        "name": "Public Health & Epidemiology",
        "icon": "📊",
        "description": "Disease surveillance, prevention, global health",
        "size_mb": 20,
    },
    "radiology": {
        "name": "Radiology & Imaging",
        "icon": "📡",
        "description": "X-ray, MRI, CT, ultrasound interpretation",
        "size_mb": 30,
    },
    "genetics": {
        "name": "Genetics & Genomics",
        "icon": "🧬",
        "description": "Genetic disorders, gene therapy, DNA diagnostics",
        "size_mb": 35,
    },
    "nutrition": {
        "name": "Nutrition & Dietetics",
        "icon": "🥗",
        "description": "Clinical nutrition, dietary therapy, vitamins",
        "size_mb": 18,
    },
    "first_aid": {
        "name": "First Aid & Basic Care",
        "icon": "🩺",
        "description": "Emergency first aid, CPR, wound care, basic procedures",
        "size_mb": 15,
    },
}

# ─── Theme ────────────────────────────────────────────────────────────────────
THEME_COLORS = {
    "dark": {
        "bg_primary": "#0F1117",
        "bg_secondary": "#1A1D27",
        "bg_tertiary": "#242836",
        "bg_chat": "#151821",
        "accent": "#00D4AA",
        "accent_hover": "#00F0C0",
        "accent_dim": "#00D4AA22",
        "text_primary": "#E8ECF4",
        "text_secondary": "#8B92A8",
        "text_muted": "#5A6178",
        "border": "#2A2E3D",
        "border_light": "#353A4D",
        "error": "#FF4B6E",
        "warning": "#FFB84D",
        "success": "#00D4AA",
        "info": "#4DA6FF",
        "user_bubble": "#1E3A5F",
        "ai_bubble": "#1A2332",
        "sidebar": "#12141D",
        "input_bg": "#1A1D27",
        "scrollbar": "#2A2E3D",
        "scrollbar_hover": "#353A4D",
    },
    "light": {
        "bg_primary": "#F7F8FC",
        "bg_secondary": "#FFFFFF",
        "bg_tertiary": "#EEF0F7",
        "bg_chat": "#F0F2F8",
        "accent": "#00A884",
        "accent_hover": "#00C49A",
        "accent_dim": "#00A88422",
        "text_primary": "#1A1D27",
        "text_secondary": "#5A6178",
        "text_muted": "#8B92A8",
        "border": "#DFE2EB",
        "border_light": "#E8EBF2",
        "error": "#E53E5E",
        "warning": "#E5A33E",
        "success": "#00A884",
        "info": "#3D8CE5",
        "user_bubble": "#DCF0FF",
        "ai_bubble": "#FFFFFF",
        "sidebar": "#ECEEF5",
        "input_bg": "#FFFFFF",
        "scrollbar": "#D0D3DE",
        "scrollbar_hover": "#B8BCC9",
    },
}
