"""
Authentication System — Local Registration + Optional Google Sign-In
No external setup required. Works out of the box.
"""
import hashlib
import secrets
import json
import threading
import webbrowser
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Optional, Callable

import requests as http_requests

from config import GOOGLE_CLIENT_SECRETS, GOOGLE_SCOPES, OAUTH_REDIRECT_PORT
import database as db


# ═══════════════════════════════════════════════════════════════════════════════
#  LOCAL AUTHENTICATION  (Works without any setup)
# ═══════════════════════════════════════════════════════════════════════════════

def _hash_password(password: str, salt: str = None) -> tuple:
    if salt is None:
        salt = secrets.token_hex(16)
    hashed = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100000)
    return hashed.hex(), salt


def register_local_user(name: str, email: str, password: str):
    """Register a new local user. Returns user dict on success, error string on failure."""
    email = email.strip().lower()
    name = name.strip()

    if not name or len(name) < 2:
        return "Name must be at least 2 characters."
    if not email or "@" not in email or "." not in email:
        return "Please enter a valid email address."
    if len(password) < 6:
        return "Password must be at least 6 characters."

    existing = db.get_user_by_email(email)
    if existing:
        return "An account with this email already exists. Please login instead."

    pw_hash, pw_salt = _hash_password(password)
    google_id = f"local_{secrets.token_hex(8)}"

    user = db.upsert_user(
        google_id=google_id, email=email,
        display_name=name, avatar_url="",
    )
    prefs = {"pw_hash": pw_hash, "pw_salt": pw_salt, "auth_type": "local"}
    db.update_user_preferences(user["id"], prefs)
    return user


def login_local_user(email: str, password: str):
    """Login with email/password. Returns user dict or error string."""
    email = email.strip().lower()
    user = db.get_user_by_email(email)
    if not user:
        return "No account found with this email. Please register first."

    try:
        prefs = json.loads(user.get("preferences", "{}"))
    except (json.JSONDecodeError, TypeError):
        prefs = {}

    stored_hash = prefs.get("pw_hash", "")
    stored_salt = prefs.get("pw_salt", "")
    if not stored_hash:
        return "This account uses Google Sign-In. Please use Google to login."

    computed_hash, _ = _hash_password(password, stored_salt)
    if computed_hash != stored_hash:
        return "Incorrect password. Please try again."
    return user


def save_login_session(email: str):
    db.set_setting("last_login_email", email)


def get_last_login_email() -> str:
    return db.get_setting("last_login_email", "")


def clear_login_session():
    db.set_setting("last_login_email", "")


# ═══════════════════════════════════════════════════════════════════════════════
#  GOOGLE OAUTH  (Optional — only works if user has client_secret.json)
# ═══════════════════════════════════════════════════════════════════════════════

def is_google_auth_available() -> bool:
    """Check if Google OAuth credentials are configured."""
    if not GOOGLE_CLIENT_SECRETS.exists():
        return False
    try:
        with open(GOOGLE_CLIENT_SECRETS) as f:
            data = json.load(f)
        key = "installed" if "installed" in data else "web"
        cid = data.get(key, {}).get("client_id", "")
        return bool(cid) and "YOUR_CLIENT_ID" not in cid
    except Exception:
        return False


class _OAuthHandler(BaseHTTPRequestHandler):
    auth_code = None
    error = None

    def do_GET(self):
        params = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        if "code" in params:
            _OAuthHandler.auth_code = params["code"][0]
            html = ("<html><body style='display:flex;justify-content:center;align-items:center;"
                    "height:100vh;font-family:system-ui;background:#0F1117;color:#00D4AA'>"
                    "<h1>✅ Signed in! Close this tab.</h1></body></html>")
        else:
            _OAuthHandler.error = params.get("error", ["unknown"])[0]
            html = ("<html><body style='display:flex;justify-content:center;align-items:center;"
                    "height:100vh;font-family:system-ui;background:#0F1117;color:#FF4B6E'>"
                    "<h1>❌ Auth failed. Try again.</h1></body></html>")
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(html.encode())

    def log_message(self, *a):
        pass


def start_google_oauth(on_complete: Callable):
    def _run():
        try:
            with open(GOOGLE_CLIENT_SECRETS) as f:
                data = json.load(f)
            key = "installed" if "installed" in data else "web"
            cfg = data[key]
            redirect = f"http://localhost:{OAUTH_REDIRECT_PORT}"

            url = ("https://accounts.google.com/o/oauth2/v2/auth?" + urllib.parse.urlencode({
                "client_id": cfg["client_id"], "redirect_uri": redirect,
                "response_type": "code", "scope": " ".join(GOOGLE_SCOPES),
                "access_type": "offline", "prompt": "consent",
            }))

            _OAuthHandler.auth_code = _OAuthHandler.error = None
            server = HTTPServer(("localhost", OAUTH_REDIRECT_PORT), _OAuthHandler)
            server.timeout = 120
            webbrowser.open(url)

            while not _OAuthHandler.auth_code and not _OAuthHandler.error:
                server.handle_request()
            server.server_close()

            if _OAuthHandler.error or not _OAuthHandler.auth_code:
                on_complete(None)
                return

            tok = http_requests.post("https://oauth2.googleapis.com/token", data={
                "code": _OAuthHandler.auth_code, "client_id": cfg["client_id"],
                "client_secret": cfg["client_secret"], "redirect_uri": redirect,
                "grant_type": "authorization_code",
            }, timeout=15)
            if tok.status_code != 200:
                on_complete(None)
                return

            tokens = tok.json()
            info_resp = http_requests.get("https://www.googleapis.com/oauth2/v2/userinfo",
                headers={"Authorization": f"Bearer {tokens['access_token']}"}, timeout=10)
            if info_resp.status_code != 200:
                on_complete(None)
                return

            info = info_resp.json()
            user = db.upsert_user(google_id=info.get("id",""), email=info.get("email",""),
                display_name=info.get("name",""), avatar_url=info.get("picture",""))
            db.update_user_preferences(user["id"], {"auth_type": "google"})
            on_complete(user)
        except Exception as e:
            print(f"[GOOGLE AUTH ERROR] {e}")
            on_complete(None)

    threading.Thread(target=_run, daemon=True).start()


def logout(email=""):
    clear_login_session()
