@echo off
setlocal EnableDelayedExpansion
title MedAI - Full Automated Setup
color 0A
cls

echo.
echo  ****************************************************************
echo  *                                                              *
echo  *              MedAI - Medical Intelligence Assistant           *
echo  *                    FULL AUTOMATED SETUP                       *
echo  *                                                              *
echo  ****************************************************************
echo.
echo  This script will install everything needed:
echo    [1] Python (if not installed)
echo    [2] Ollama AI (if not installed)
echo    [3] Python packages (customtkinter, ollama, etc.)
echo    [4] AI Model download (llama3.1 ~4.7 GB)
echo.
echo  Press any key to begin or close this window to cancel...
pause >nul
echo.

:: ================================================================
::  STEP 1: CHECK PYTHON
:: ================================================================
echo  [STEP 1/5] Checking Python...
echo  ------------------------------------------------

python --version >nul 2>&1
if !errorlevel! neq 0 (
    echo  Python not found. Downloading Python installer...
    echo.
    set "PYURL=https://www.python.org/ftp/python/3.12.4/python-3.12.4-amd64.exe"
    set "PYINST=%TEMP%\python_installer.exe"
    echo  Downloading from python.org...
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '!PYURL!' -OutFile '!PYINST!'"
    if not exist "!PYINST!" (
        echo.
        echo  ERROR: Could not download Python automatically.
        echo  Please install Python manually:
        echo    1. Go to https://www.python.org/downloads/
        echo    2. Download Python 3.12 or later
        echo    3. CHECK the box "Add Python to PATH" during install
        echo    4. Run this setup.bat again
        echo.
        pause
        exit /b 1
    )
    echo  Installing Python... This may take 2-3 minutes.
    echo  NOTE: If a dialog appears, check "Add to PATH" and click Install.
    "!PYINST!" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_tcltk=1
    if !errorlevel! neq 0 (
        echo  Silent install did not work. Opening interactive installer...
        echo  IMPORTANT: Check "Add python.exe to PATH" at the bottom!
        "!PYINST!"
    )
    del "!PYINST!" >nul 2>&1
    set "PATH=%LOCALAPPDATA%\Programs\Python\Python312\;%LOCALAPPDATA%\Programs\Python\Python312\Scripts\;%PATH%"
    python --version >nul 2>&1
    if !errorlevel! neq 0 (
        echo.
        echo  Python still not detected after install.
        echo  Please close this window, open a NEW command prompt,
        echo  and run setup.bat again.
        echo.
        pause
        exit /b 1
    )
)

for /f "tokens=*" %%i in ('python --version 2^>^&1') do echo  OK: %%i
echo.

:: ================================================================
::  STEP 2: CHECK OLLAMA
:: ================================================================
echo  [STEP 2/5] Checking Ollama...
echo  ------------------------------------------------

ollama --version >nul 2>&1
if !errorlevel! neq 0 (
    echo  Ollama not found. Downloading Ollama installer...
    echo.
    set "OLURL=https://ollama.com/download/OllamaSetup.exe"
    set "OLINST=%TEMP%\OllamaSetup.exe"
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '!OLURL!' -OutFile '!OLINST!'"
    if not exist "!OLINST!" (
        echo.
        echo  ERROR: Could not download Ollama automatically.
        echo  Please install manually from: https://ollama.com/download
        echo  Then run this setup.bat again.
        echo.
        pause
        exit /b 1
    )
    echo  Installing Ollama... Follow the installer if it appears.
    "!OLINST!"
    del "!OLINST!" >nul 2>&1
    timeout /t 5 /nobreak >nul
    set "PATH=%LOCALAPPDATA%\Programs\Ollama\;%ProgramFiles%\Ollama\;%PATH%"
)

ollama --version >nul 2>&1
if !errorlevel! equ 0 (
    echo  OK: Ollama installed
) else (
    echo  WARNING: Ollama not detected yet. You may need to restart
    echo  your computer. The app can still open without it.
)
echo.

:: ================================================================
::  STEP 3: PYTHON VIRTUAL ENVIRONMENT + PACKAGES
:: ================================================================
echo  [STEP 3/5] Setting up Python environment...
echo  ------------------------------------------------

if not exist "venv" (
    echo  Creating virtual environment...
    python -m venv venv
    if !errorlevel! neq 0 (
        echo  ERROR: Failed to create virtual environment.
        pause
        exit /b 1
    )
    echo  Virtual environment created.
) else (
    echo  Virtual environment already exists.
)

echo  Activating...
call venv\Scripts\activate.bat

echo  Upgrading pip...
python -m pip install --upgrade pip >nul 2>&1

echo.
echo  Installing all required packages...
echo  This may take 3-5 minutes on first run...
echo.
pip install customtkinter ollama Pillow requests google-auth google-auth-oauthlib google-api-python-client cryptography
echo.

if !errorlevel! neq 0 (
    echo  Some packages may have failed. Trying one by one...
    pip install customtkinter
    pip install ollama
    pip install Pillow
    pip install requests
    pip install google-auth
    pip install google-auth-oauthlib
    pip install google-api-python-client
    pip install cryptography
)

echo  Packages installed.
echo.

:: ================================================================
::  STEP 4: PULL AI MODEL
:: ================================================================
echo  [STEP 4/5] Setting up AI Model...
echo  ------------------------------------------------

echo  Starting Ollama service...
start /min "OllamaService" ollama serve 2>nul
timeout /t 5 /nobreak >nul

curl -s http://localhost:11434/api/tags >nul 2>&1
if !errorlevel! equ 0 (
    echo  Ollama is running.
    echo.
    echo  Downloading AI model: llama3.1
    echo  This is about 4.7 GB. It may take 10-30 minutes.
    echo  You can press Ctrl+C to skip and download later.
    echo.
    ollama pull llama3.1
) else (
    echo  WARNING: Ollama is not responding right now.
    echo  You can download the model later by running:
    echo    ollama serve        (in one terminal)
    echo    ollama pull llama3.1  (in another terminal)
)
echo.

:: ================================================================
::  STEP 5: CREATE DIRECTORIES + ICON
:: ================================================================
echo  [STEP 5/5] Finishing setup...
echo  ------------------------------------------------

if not exist "data\medical_fields" mkdir "data\medical_fields"
if not exist "data\database" mkdir "data\database"
if not exist "data\cache" mkdir "data\cache"
if not exist "assets" mkdir "assets"
if not exist "auth\tokens" mkdir "auth\tokens"

echo  Generating app icon...
python generate_icon.py 2>nul
echo  Done.
echo.

:: ================================================================
::  DONE
:: ================================================================
echo.
echo  ****************************************************************
echo  *                                                              *
echo  *                   SETUP COMPLETE!                             *
echo  *                                                              *
echo  *  To run MedAI: double-click  run_module.bat                  *
echo  *                                                              *
echo  *  First time:                                                  *
echo  *    1. Double-click run_module.bat                             *
echo  *    2. Click "Register" and create your account               *
echo  *    3. Start chatting about any medical topic!                 *
echo  *                                                              *
echo  ****************************************************************
echo.
pause
