"""
Core AI Engine — Ollama integration + Medical Knowledge Base
Handles online/offline modes, streaming, and context management.
"""
import json
import os
import threading
import time
from pathlib import Path
from typing import Optional, Generator, Callable

import requests

from config import (
    OLLAMA_HOST,
    OLLAMA_MODEL,
    OLLAMA_FALLBACK_MODELS,
    OLLAMA_TIMEOUT,
    MEDICAL_SYSTEM_PROMPT,
    MEDICAL_DATA_DIR,
    MEDICAL_SUBFIELDS,
)


# ═══════════════════════════════════════════════════════════════════════════════
#  Ollama Engine
# ═══════════════════════════════════════════════════════════════════════════════

class OllamaEngine:
    """Interface to the Ollama local LLM server."""

    def __init__(self):
        self.host = OLLAMA_HOST
        self.model = OLLAMA_MODEL
        self._available_models: list = []
        self._is_online = False

    # ── Status ────────────────────────────────────────────────────────────────

    def check_connection(self) -> bool:
        try:
            r = requests.get(f"{self.host}/api/tags", timeout=5)
            self._is_online = r.status_code == 200
            if self._is_online:
                data = r.json()
                self._available_models = [m["name"] for m in data.get("models", [])]
        except Exception:
            self._is_online = False
            self._available_models = []
        return self._is_online

    @property
    def is_online(self) -> bool:
        return self._is_online

    @property
    def available_models(self) -> list:
        return self._available_models

    def get_active_model(self) -> str:
        """Return the best available model."""
        if self.model in self._available_models:
            return self.model
        for fallback in OLLAMA_FALLBACK_MODELS:
            for avail in self._available_models:
                if fallback in avail:
                    return avail
        if self._available_models:
            return self._available_models[0]
        return self.model

    # ── Chat ──────────────────────────────────────────────────────────────────

    def chat_stream(
        self,
        messages: list[dict],
        offline_context: str = "",
        on_token: Callable[[str], None] = None,
        on_done: Callable[[str], None] = None,
        on_error: Callable[[str], None] = None,
    ):
        """Stream a chat response. Runs in a background thread."""

        def _run():
            try:
                system = MEDICAL_SYSTEM_PROMPT
                if offline_context:
                    system += (
                        "\n\n--- OFFLINE KNOWLEDGE BASE ---\n"
                        "The user is in OFFLINE mode. Use the following downloaded medical "
                        "knowledge to answer. If the question is outside this data, let the "
                        "user know they may need to download more fields or go online.\n\n"
                        + offline_context
                    )

                full_messages = [{"role": "system", "content": system}] + messages
                model = self.get_active_model()

                resp = requests.post(
                    f"{self.host}/api/chat",
                    json={"model": model, "messages": full_messages, "stream": True},
                    stream=True,
                    timeout=OLLAMA_TIMEOUT,
                )
                resp.raise_for_status()

                full_response = ""
                for line in resp.iter_lines():
                    if not line:
                        continue
                    try:
                        chunk = json.loads(line)
                        token = chunk.get("message", {}).get("content", "")
                        if token:
                            full_response += token
                            if on_token:
                                on_token(token)
                        if chunk.get("done", False):
                            break
                    except json.JSONDecodeError:
                        continue

                if on_done:
                    on_done(full_response)

            except requests.exceptions.ConnectionError:
                if on_error:
                    on_error("Cannot connect to Ollama. Make sure Ollama is running (ollama serve).")
            except requests.exceptions.Timeout:
                if on_error:
                    on_error("Response timed out. The model may be loading or the query too complex.")
            except Exception as e:
                if on_error:
                    on_error(f"Error: {str(e)}")

        thread = threading.Thread(target=_run, daemon=True)
        thread.start()

    def chat_sync(self, messages: list[dict], offline_context: str = "") -> str:
        """Synchronous single-shot chat (for title generation etc.)."""
        try:
            system = MEDICAL_SYSTEM_PROMPT
            if offline_context:
                system += "\n\n" + offline_context

            full_messages = [{"role": "system", "content": system}] + messages
            model = self.get_active_model()

            resp = requests.post(
                f"{self.host}/api/chat",
                json={"model": model, "messages": full_messages, "stream": False},
                timeout=OLLAMA_TIMEOUT,
            )
            resp.raise_for_status()
            return resp.json().get("message", {}).get("content", "")
        except Exception as e:
            return f"[Error: {e}]"

    def generate_title(self, first_message: str) -> str:
        """Generate a short chat title from the first user message."""
        messages = [
            {
                "role": "user",
                "content": (
                    f"Generate a short title (max 6 words) for a medical chat that starts with:\n"
                    f'"{first_message[:200]}"\n\nRespond with ONLY the title, nothing else.'
                ),
            }
        ]
        title = self.chat_sync(messages)
        title = title.strip().strip('"').strip("'")
        return title[:60] if title else "Medical Chat"

    # ── Model Management ──────────────────────────────────────────────────────

    def pull_model(self, model_name: str, on_progress: Callable[[str], None] = None):
        """Pull/download a model from Ollama."""
        def _run():
            try:
                resp = requests.post(
                    f"{self.host}/api/pull",
                    json={"name": model_name, "stream": True},
                    stream=True,
                    timeout=600,
                )
                for line in resp.iter_lines():
                    if line:
                        data = json.loads(line)
                        status = data.get("status", "")
                        if on_progress:
                            on_progress(status)
            except Exception as e:
                if on_progress:
                    on_progress(f"Error: {e}")
        threading.Thread(target=_run, daemon=True).start()


# ═══════════════════════════════════════════════════════════════════════════════
#  Medical Knowledge Base Manager
# ═══════════════════════════════════════════════════════════════════════════════

class MedicalKnowledgeBase:
    """Manages downloadable medical knowledge for offline use."""

    def __init__(self):
        self.data_dir = MEDICAL_DATA_DIR
        self.fields = MEDICAL_SUBFIELDS

    def get_downloaded_fields(self) -> list[str]:
        """Return list of field keys that have been downloaded locally."""
        downloaded = []
        for key in self.fields:
            path = self.data_dir / f"{key}.json"
            if path.exists():
                downloaded.append(key)
        return downloaded

    def is_field_downloaded(self, field_key: str) -> bool:
        return (self.data_dir / f"{field_key}.json").exists()

    def get_field_data(self, field_key: str) -> Optional[dict]:
        path = self.data_dir / f"{field_key}.json"
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        return None

    def get_offline_context(self, field_keys: list[str] = None) -> str:
        """Build context string from downloaded fields."""
        if field_keys is None:
            field_keys = self.get_downloaded_fields()

        context_parts = []
        for key in field_keys:
            data = self.get_field_data(key)
            if data:
                field_info = self.fields.get(key, {})
                context_parts.append(
                    f"\n## {field_info.get('icon', '📋')} {field_info.get('name', key)}\n"
                    + data.get("summary", "")
                    + "\n"
                    + "\n".join(
                        f"- **{item.get('topic', '')}**: {item.get('info', '')}"
                        for item in data.get("entries", [])[:100]  # limit for context
                    )
                )

        return "\n".join(context_parts) if context_parts else ""

    def generate_field_data(self, field_key: str, engine: OllamaEngine,
                            on_progress: Callable[[int], None] = None) -> bool:
        """Use the AI to generate comprehensive knowledge for a field."""
        field_info = self.fields.get(field_key)
        if not field_info:
            return False

        try:
            topics = self._get_field_topics(field_key)
            entries = []

            for i, topic in enumerate(topics):
                prompt = (
                    f"Provide a concise but comprehensive medical reference entry about: "
                    f"{topic} (in the context of {field_info['name']}). "
                    f"Include key facts, clinical relevance, and important details. "
                    f"Keep it under 300 words. Be factual and precise."
                )

                response = engine.chat_sync([{"role": "user", "content": prompt}])
                entries.append({"topic": topic, "info": response})

                if on_progress:
                    on_progress(int((i + 1) / len(topics) * 100))

            data = {
                "field_key": field_key,
                "field_name": field_info["name"],
                "description": field_info["description"],
                "summary": f"Comprehensive reference for {field_info['name']}.",
                "entries": entries,
                "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "entry_count": len(entries),
            }

            path = self.data_dir / f"{field_key}.json"
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)

            return True

        except Exception as e:
            print(f"[KB ERROR] Failed to generate {field_key}: {e}")
            return False

    def delete_field_data(self, field_key: str):
        path = self.data_dir / f"{field_key}.json"
        if path.exists():
            path.unlink()

    def get_total_downloaded_size(self) -> int:
        """Return total size of downloaded data in bytes."""
        total = 0
        for key in self.get_downloaded_fields():
            path = self.data_dir / f"{key}.json"
            total += path.stat().st_size
        return total

    @staticmethod
    def _get_field_topics(field_key: str) -> list[str]:
        """Return a list of important topics for each medical field."""
        topic_map = {
            "anatomy_physiology": [
                "Cardiovascular System", "Respiratory System", "Nervous System",
                "Digestive System", "Musculoskeletal System", "Endocrine System",
                "Urinary System", "Reproductive System", "Lymphatic System",
                "Integumentary System", "Cell Biology Basics", "Histology Overview",
                "Homeostasis Mechanisms", "Blood Composition and Function",
                "Major Bones and Joints",
            ],
            "pharmacology": [
                "Analgesics (NSAIDs and Opioids)", "Antibiotics Overview",
                "Antihypertensives", "Antidiabetic Drugs", "Antidepressants",
                "Anticoagulants", "Bronchodilators", "Corticosteroids",
                "Chemotherapy Agents", "Immunosuppressants", "Cardiac Glycosides",
                "Proton Pump Inhibitors", "Drug Interactions Principles",
                "Pharmacokinetics ADME", "Adverse Drug Reactions",
            ],
            "microbiology": [
                "Gram-Positive Bacteria", "Gram-Negative Bacteria",
                "DNA Viruses", "RNA Viruses", "Pathogenic Fungi",
                "Protozoan Parasites", "Helminths", "Prions",
                "Antibiotic Resistance Mechanisms", "Biofilm Formation",
                "Koch's Postulates", "Viral Replication Cycles",
                "Hospital-Acquired Infections", "Zoonotic Diseases",
                "Emerging Infectious Diseases",
            ],
            "pathology": [
                "Inflammation Acute and Chronic", "Neoplasia Classification",
                "Cellular Injury and Death", "Hemodynamic Disorders",
                "Genetic Diseases Overview", "Autoimmune Diseases",
                "Nutritional Deficiency Diseases", "Environmental Diseases",
                "Infectious Disease Pathology", "Immunodeficiency Disorders",
                "Amyloidosis", "Granulomatous Diseases",
                "Degenerative Diseases", "Metabolic Disorders", "Congenital Anomalies",
            ],
            "surgery": [
                "Preoperative Assessment", "Wound Healing",
                "Surgical Infections", "Fluid and Electrolyte Management",
                "Anesthesia Types", "Laparoscopic Surgery Principles",
                "Trauma Management", "Burns Classification and Treatment",
                "Hernia Repair", "Appendectomy", "Cholecystectomy",
                "Fracture Management", "Organ Transplantation",
                "Postoperative Complications", "Surgical Instruments Overview",
            ],
            "cardiology": [
                "Coronary Artery Disease", "Heart Failure",
                "Arrhythmias", "Valvular Heart Disease", "Hypertension",
                "Myocardial Infarction", "Cardiomyopathies",
                "Congenital Heart Defects", "Pericardial Diseases",
                "ECG Interpretation Basics", "Cardiac Catheterization",
                "Echocardiography", "Atherosclerosis", "Peripheral Vascular Disease",
                "Cardiac Rehabilitation",
            ],
            "neurology": [
                "Stroke (Ischemic and Hemorrhagic)", "Epilepsy and Seizures",
                "Parkinson's Disease", "Alzheimer's Disease",
                "Multiple Sclerosis", "Meningitis and Encephalitis",
                "Peripheral Neuropathy", "Headache Disorders",
                "Brain Tumors", "Spinal Cord Injuries",
                "Neuromuscular Disorders", "Movement Disorders",
                "Demyelinating Diseases", "Cranial Nerve Disorders",
                "Neurological Examination",
            ],
            "oncology": [
                "Cancer Biology and Genetics", "Lung Cancer",
                "Breast Cancer", "Colorectal Cancer", "Leukemia",
                "Lymphoma", "Prostate Cancer", "Cervical Cancer",
                "Liver Cancer", "Pancreatic Cancer",
                "Chemotherapy Principles", "Radiation Therapy",
                "Immunotherapy", "Cancer Staging (TNM)", "Palliative Care",
            ],
            "pediatrics": [
                "Neonatal Care", "Growth and Development Milestones",
                "Childhood Vaccinations", "Pediatric Infectious Diseases",
                "Congenital Disorders", "Pediatric Respiratory Diseases",
                "Childhood Nutrition", "Pediatric Emergencies",
                "Developmental Delays", "Childhood Cancer",
                "Pediatric Cardiology", "Adolescent Health",
                "Failure to Thrive", "ADHD and Learning Disorders",
                "Child Abuse Recognition",
            ],
            "psychiatry": [
                "Major Depressive Disorder", "Bipolar Disorder",
                "Schizophrenia", "Anxiety Disorders", "PTSD",
                "OCD", "Eating Disorders", "Personality Disorders",
                "Substance Use Disorders", "Sleep Disorders",
                "Psychopharmacology", "Cognitive Behavioral Therapy",
                "Delirium vs Dementia", "Suicide Risk Assessment",
                "Child and Adolescent Psychiatry",
            ],
            "emergency_medicine": [
                "ABCDE Assessment", "CPR and BLS Protocols",
                "ACLS Algorithms", "Trauma Assessment (ATLS)",
                "Acute Coronary Syndrome", "Stroke Protocol",
                "Anaphylaxis Management", "Poisoning and Overdose",
                "Shock Classification and Treatment", "Airway Management",
                "Fracture and Dislocation Management",
                "Burn Management", "Bleeding Control",
                "Pediatric Emergencies", "Disaster Medicine",
            ],
            "dermatology": [
                "Eczema and Dermatitis", "Psoriasis", "Acne Vulgaris",
                "Skin Infections (Bacterial, Viral, Fungal)",
                "Skin Cancer (Melanoma, BCC, SCC)", "Urticaria",
                "Pemphigus and Bullous Diseases", "Drug Eruptions",
                "Pigmentation Disorders", "Hair and Nail Disorders",
                "Autoimmune Skin Diseases", "Parasitic Skin Infections",
                "Wound Care Principles", "Cosmetic Dermatology", "Skin Biopsy",
            ],
            "orthopedics": [
                "Fracture Types and Healing", "Osteoarthritis",
                "Rheumatoid Arthritis", "Osteoporosis",
                "Intervertebral Disc Disease", "Scoliosis",
                "Rotator Cuff Injuries", "ACL and Meniscal Injuries",
                "Hip Replacement", "Knee Replacement",
                "Bone Tumors", "Compartment Syndrome",
                "Tendon Injuries", "Carpal Tunnel Syndrome",
                "Sports Medicine Basics",
            ],
            "endocrinology": [
                "Diabetes Mellitus Type 1 and 2", "Thyroid Disorders",
                "Adrenal Disorders (Cushing's, Addison's)",
                "Pituitary Disorders", "Parathyroid Disorders",
                "Polycystic Ovary Syndrome", "Metabolic Syndrome",
                "Obesity Pathophysiology", "Calcium Metabolism",
                "Growth Hormone Disorders", "Insulin Resistance",
                "Diabetic Complications", "Thyroid Cancer",
                "Hormone Replacement Therapy", "Electrolyte Disorders",
            ],
            "immunology": [
                "Innate Immunity", "Adaptive Immunity",
                "Antibody Structure and Function", "T Cell Biology",
                "Hypersensitivity Reactions (Types I-IV)",
                "Autoimmune Disease Mechanisms", "Immunodeficiency Diseases",
                "Transplant Immunology", "Vaccine Immunology",
                "Allergy Mechanisms", "Complement System",
                "Cytokines and Chemokines", "Immunotherapy Principles",
                "HIV/AIDS Immunology", "Tumor Immunology",
            ],
            "public_health": [
                "Epidemiological Study Designs", "Disease Surveillance",
                "Vaccination Programs", "Waterborne Disease Prevention",
                "Maternal and Child Health", "Nutrition and Public Health",
                "Pandemic Preparedness", "Health Screening Programs",
                "Occupational Health", "Environmental Health Hazards",
                "Biostatistics Basics", "Health Policy Frameworks",
                "Global Disease Burden", "Social Determinants of Health",
                "Antimicrobial Resistance (Global Perspective)",
            ],
            "radiology": [
                "X-Ray Interpretation Basics", "CT Scan Principles",
                "MRI Principles and Applications", "Ultrasound Basics",
                "Chest X-Ray Interpretation", "Abdominal Imaging",
                "Neuroimaging", "Musculoskeletal Imaging",
                "Cardiac Imaging", "Breast Imaging (Mammography)",
                "Nuclear Medicine", "PET Scan Applications",
                "Radiation Safety", "Contrast Media",
                "Interventional Radiology",
            ],
            "genetics": [
                "Mendelian Inheritance", "Chromosomal Disorders",
                "Single Gene Disorders", "Multifactorial Inheritance",
                "Genetic Testing Methods", "Gene Therapy",
                "Epigenetics", "Cancer Genetics",
                "Pharmacogenomics", "Prenatal Genetic Testing",
                "CRISPR and Gene Editing", "Mitochondrial Disorders",
                "Genetic Counseling", "Population Genetics",
                "Genomic Medicine Applications",
            ],
            "nutrition": [
                "Macronutrients (Carbs, Proteins, Fats)",
                "Micronutrients (Vitamins and Minerals)",
                "Clinical Malnutrition", "Enteral and Parenteral Nutrition",
                "Diabetes Dietary Management", "Cardiac Diet",
                "Renal Diet", "Obesity and Weight Management",
                "Eating Disorders Nutrition", "Pediatric Nutrition",
                "Geriatric Nutrition", "Sports Nutrition",
                "Food Allergies and Intolerances",
                "Nutritional Assessment Methods", "Functional Foods",
            ],
            "first_aid": [
                "CPR (Adult, Child, Infant)", "Choking Management",
                "Wound Care and Bandaging", "Fracture First Aid",
                "Burn First Aid", "Bleeding Control",
                "Shock Recognition and Management", "Snake and Insect Bites",
                "Heat and Cold Emergencies", "Drowning Response",
                "Allergic Reaction First Aid", "Seizure First Aid",
                "Diabetic Emergency First Aid", "Eye Injury First Aid",
                "Basic Vital Signs Assessment",
            ],
        }
        return topic_map.get(field_key, [f"{field_key} overview"])
