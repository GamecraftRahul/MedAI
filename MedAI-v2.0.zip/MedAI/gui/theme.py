"""
GUI Theme Manager & Utilities
Provides consistent styling across the application.
"""
import customtkinter as ctk
from config import THEME_COLORS


class ThemeManager:
    """Centralized theme management."""

    _current = "dark"
    _colors = THEME_COLORS["dark"]

    @classmethod
    def get(cls, key: str) -> str:
        return cls._colors.get(key, "#FFFFFF")

    @classmethod
    def toggle(cls):
        cls._current = "light" if cls._current == "dark" else "dark"
        cls._colors = THEME_COLORS[cls._current]

    @classmethod
    def is_dark(cls) -> bool:
        return cls._current == "dark"

    @classmethod
    def mode(cls) -> str:
        return cls._current


TM = ThemeManager


def styled_button(parent, text, command=None, style="primary", width=None, height=36, **kw):
    """Create a consistently styled button."""
    colors = {
        "primary": (TM.get("accent"), TM.get("accent_hover"), TM.get("bg_primary")),
        "secondary": (TM.get("bg_tertiary"), TM.get("border_light"), TM.get("text_primary")),
        "danger": (TM.get("error"), "#FF6B88", "#FFFFFF"),
        "ghost": ("transparent", TM.get("bg_tertiary"), TM.get("text_secondary")),
    }
    fg, hover, text_c = colors.get(style, colors["primary"])
    config = dict(
        text=text,
        command=command,
        fg_color=fg,
        hover_color=hover,
        text_color=text_c,
        height=height,
        corner_radius=8,
        font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
        border_width=1 if style == "secondary" else 0,
        border_color=TM.get("border") if style == "secondary" else None,
    )
    if width:
        config["width"] = width
    config.update(kw)
    return ctk.CTkButton(parent, **config)


def styled_entry(parent, placeholder="", show=None, width=None, height=40, **kw):
    """Create a styled text entry."""
    config = dict(
        placeholder_text=placeholder,
        fg_color=TM.get("input_bg"),
        text_color=TM.get("text_primary"),
        placeholder_text_color=TM.get("text_muted"),
        border_color=TM.get("border"),
        border_width=1,
        corner_radius=8,
        height=height,
        font=ctk.CTkFont(family="Segoe UI", size=13),
    )
    if show:
        config["show"] = show
    if width:
        config["width"] = width
    config.update(kw)
    return ctk.CTkEntry(parent, **config)


def styled_label(parent, text, size=13, weight="normal", color=None, **kw):
    """Create a styled label."""
    config = dict(
        text=text,
        text_color=color or TM.get("text_primary"),
        font=ctk.CTkFont(family="Segoe UI", size=size, weight=weight),
    )
    config.update(kw)
    return ctk.CTkLabel(parent, **config)
