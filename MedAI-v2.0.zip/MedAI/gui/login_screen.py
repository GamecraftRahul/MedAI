"""
Login Screen — Local Registration / Login + Optional Google Sign-In
Works out of the box without any external setup.
"""
import customtkinter as ctk
from gui.theme import TM, styled_button, styled_label, styled_entry


class LoginScreen(ctk.CTkFrame):
    """Full-screen login with Register / Login / Google options."""

    def __init__(self, parent, on_local_login, on_local_register, on_google_login,
                 google_available: bool = False, prefill_email: str = ""):
        super().__init__(parent, fg_color=TM.get("bg_primary"))
        self.on_local_login = on_local_login
        self.on_local_register = on_local_register
        self.on_google_login = on_google_login
        self.google_available = google_available
        self.prefill_email = prefill_email
        self._mode = "login"  # "login" or "register"
        self._build()

    def _build(self):
        # Center container
        self.center = ctk.CTkFrame(self, fg_color="transparent")
        self.center.place(relx=0.5, rely=0.5, anchor="center")
        self._build_content()

    def _build_content(self):
        # Clear previous
        for w in self.center.winfo_children():
            w.destroy()

        # ── Logo ──────────────────────────────────────────────────────────
        styled_label(self.center, "🏥", size=52).pack(pady=(0, 4))
        styled_label(self.center, "MedAI", size=38, weight="bold",
                     color=TM.get("accent")).pack(pady=(0, 2))
        styled_label(self.center, "Medical Intelligence Assistant", size=14,
                     color=TM.get("text_secondary")).pack(pady=(0, 24))

        # ── Card ──────────────────────────────────────────────────────────
        card = ctk.CTkFrame(self.center, fg_color=TM.get("bg_secondary"),
                            corner_radius=16, border_width=1, border_color=TM.get("border"))
        card.pack(padx=20)

        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(padx=36, pady=32)

        if self._mode == "register":
            self._build_register_form(inner)
        else:
            self._build_login_form(inner)

        # ── Bottom info ───────────────────────────────────────────────────
        styled_label(self.center, "Powered by Ollama  •  Local AI  •  Your Data Stays Private",
                     size=10, color=TM.get("text_muted")).pack(pady=(24, 0))

    def _build_login_form(self, parent):
        styled_label(parent, "Welcome Back", size=20, weight="bold").pack(anchor="w", pady=(0, 4))
        styled_label(parent, "Sign in to continue your medical research",
                     size=12, color=TM.get("text_secondary")).pack(anchor="w", pady=(0, 20))

        # Email
        styled_label(parent, "Email", size=12, weight="bold",
                     color=TM.get("text_secondary")).pack(anchor="w", pady=(0, 4))
        self.email_entry = styled_entry(parent, placeholder="your.email@gmail.com", width=320)
        self.email_entry.pack(pady=(0, 12))
        if self.prefill_email:
            self.email_entry.insert(0, self.prefill_email)

        # Password
        styled_label(parent, "Password", size=12, weight="bold",
                     color=TM.get("text_secondary")).pack(anchor="w", pady=(0, 4))
        self.pass_entry = styled_entry(parent, placeholder="Enter your password",
                                       show="●", width=320)
        self.pass_entry.pack(pady=(0, 20))
        self.pass_entry.bind("<Return>", lambda e: self._do_login())

        # Login button
        styled_button(parent, "🔓  Sign In", command=self._do_login,
                      style="primary", width=320, height=44).pack(pady=(0, 12))

        # Status
        self.status_label = styled_label(parent, "", size=11, color=TM.get("error"))
        self.status_label.pack(pady=(0, 8))

        # Separator
        sep_frame = ctk.CTkFrame(parent, fg_color="transparent")
        sep_frame.pack(fill="x", pady=(4, 12))
        ctk.CTkFrame(sep_frame, height=1, fg_color=TM.get("border")).place(
            relx=0, rely=0.5, relwidth=0.4)
        styled_label(sep_frame, "  or  ", size=11, color=TM.get("text_muted")).pack()
        ctk.CTkFrame(sep_frame, height=1, fg_color=TM.get("border")).place(
            relx=0.6, rely=0.5, relwidth=0.4)

        # Google button (if available)
        if self.google_available:
            ctk.CTkButton(
                parent, text="   🔑  Sign in with Google   ",
                command=self._do_google,
                fg_color="#FFFFFF" if TM.is_dark() else "#4285F4",
                hover_color="#F0F0F0" if TM.is_dark() else "#3574D4",
                text_color="#333333" if TM.is_dark() else "#FFFFFF",
                font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
                height=42, width=320, corner_radius=21,
                border_width=1, border_color="#DDD" if TM.is_dark() else "#4285F4",
            ).pack(pady=(0, 12))
        else:
            styled_label(parent, "💡 Google Sign-In available after OAuth setup (optional)",
                         size=10, color=TM.get("text_muted")).pack(pady=(0, 12))

        # Switch to register
        switch_frame = ctk.CTkFrame(parent, fg_color="transparent")
        switch_frame.pack()
        styled_label(switch_frame, "Don't have an account?", size=12,
                     color=TM.get("text_secondary")).pack(side="left")
        ctk.CTkButton(switch_frame, text="Register", command=self._switch_to_register,
                      fg_color="transparent", hover_color=TM.get("bg_tertiary"),
                      text_color=TM.get("accent"), font=ctk.CTkFont(size=12, weight="bold"),
                      width=70, height=24).pack(side="left")

    def _build_register_form(self, parent):
        styled_label(parent, "Create Account", size=20, weight="bold").pack(anchor="w", pady=(0, 4))
        styled_label(parent, "Register to save your chats and medical research",
                     size=12, color=TM.get("text_secondary")).pack(anchor="w", pady=(0, 20))

        # Full Name
        styled_label(parent, "Full Name", size=12, weight="bold",
                     color=TM.get("text_secondary")).pack(anchor="w", pady=(0, 4))
        self.name_entry = styled_entry(parent, placeholder="Your full name", width=320)
        self.name_entry.pack(pady=(0, 12))

        # Email
        styled_label(parent, "Email", size=12, weight="bold",
                     color=TM.get("text_secondary")).pack(anchor="w", pady=(0, 4))
        self.email_entry = styled_entry(parent, placeholder="your.email@gmail.com", width=320)
        self.email_entry.pack(pady=(0, 12))

        # Password
        styled_label(parent, "Password", size=12, weight="bold",
                     color=TM.get("text_secondary")).pack(anchor="w", pady=(0, 4))
        self.pass_entry = styled_entry(parent, placeholder="Min 6 characters",
                                       show="●", width=320)
        self.pass_entry.pack(pady=(0, 12))

        # Confirm Password
        styled_label(parent, "Confirm Password", size=12, weight="bold",
                     color=TM.get("text_secondary")).pack(anchor="w", pady=(0, 4))
        self.confirm_entry = styled_entry(parent, placeholder="Re-enter password",
                                          show="●", width=320)
        self.confirm_entry.pack(pady=(0, 20))
        self.confirm_entry.bind("<Return>", lambda e: self._do_register())

        # Register button
        styled_button(parent, "📝  Create Account", command=self._do_register,
                      style="primary", width=320, height=44).pack(pady=(0, 12))

        # Status
        self.status_label = styled_label(parent, "", size=11, color=TM.get("error"))
        self.status_label.pack(pady=(0, 12))

        # Switch to login
        switch_frame = ctk.CTkFrame(parent, fg_color="transparent")
        switch_frame.pack()
        styled_label(switch_frame, "Already have an account?", size=12,
                     color=TM.get("text_secondary")).pack(side="left")
        ctk.CTkButton(switch_frame, text="Sign In", command=self._switch_to_login,
                      fg_color="transparent", hover_color=TM.get("bg_tertiary"),
                      text_color=TM.get("accent"), font=ctk.CTkFont(size=12, weight="bold"),
                      width=60, height=24).pack(side="left")

    # ── Actions ───────────────────────────────────────────────────────────

    def _do_login(self):
        email = self.email_entry.get().strip()
        password = self.pass_entry.get()
        if not email or not password:
            self.show_error("Please fill in all fields.")
            return
        self.on_local_login(email, password)

    def _do_register(self):
        name = self.name_entry.get().strip()
        email = self.email_entry.get().strip()
        password = self.pass_entry.get()
        confirm = self.confirm_entry.get()
        if not name or not email or not password:
            self.show_error("Please fill in all fields.")
            return
        if password != confirm:
            self.show_error("Passwords do not match.")
            return
        self.on_local_register(name, email, password)

    def _do_google(self):
        self.status_label.configure(text="Opening browser...", text_color=TM.get("info"))
        self.on_google_login()

    def _switch_to_register(self):
        self._mode = "register"
        self._build_content()

    def _switch_to_login(self):
        self._mode = "login"
        self._build_content()

    def show_error(self, msg: str):
        self.status_label.configure(text=msg, text_color=TM.get("error"))

    def show_success(self, msg: str):
        self.status_label.configure(text=msg, text_color=TM.get("success"))

    def show_status(self, msg: str):
        self.status_label.configure(text=msg, text_color=TM.get("info"))
