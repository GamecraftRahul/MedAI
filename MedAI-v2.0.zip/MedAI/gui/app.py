"""
MedAI Application — Main Orchestrator
Manages screens, state, and coordinates between components.
"""
import customtkinter as ctk
import threading
from typing import Optional

from config import APP_NAME, WINDOW_WIDTH, WINDOW_HEIGHT, MIN_WIDTH, MIN_HEIGHT
from gui.theme import TM
from gui.login_screen import LoginScreen
from gui.chat_screen import ChatScreen
from gui.sidebar import Sidebar
from gui.download_screen import DownloadScreen
from gui.settings_screen import SettingsScreen
from core import OllamaEngine, MedicalKnowledgeBase
import database as db
import auth


class MedAIApp(ctk.CTk):
    """Root application window and controller."""

    def __init__(self):
        super().__init__()

        # ── Window setup ──────────────────────────────────────────────────
        self.title(APP_NAME)
        self.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
        self.minsize(MIN_WIDTH, MIN_HEIGHT)
        self.configure(fg_color=TM.get("bg_primary"))

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")

        try:
            from config import APP_ICON
            if APP_ICON.exists():
                self.iconbitmap(str(APP_ICON))
        except Exception:
            pass

        # ── Core components ───────────────────────────────────────────────
        self.engine = OllamaEngine()
        self.kb = MedicalKnowledgeBase()

        # ── State ─────────────────────────────────────────────────────────
        self.current_user: Optional[dict] = None
        self.current_session_id: int = -1
        self.is_offline_mode: bool = False
        self._chat_messages: list[dict] = []

        # ── Initialize ────────────────────────────────────────────────────
        db.init_db()
        self.engine.check_connection()

        self.login_screen: Optional[LoginScreen] = None
        self.sidebar: Optional[Sidebar] = None
        self.chat_screen: Optional[ChatScreen] = None

        # Check for auto-login
        last_email = auth.get_last_login_email()
        if last_email:
            user = db.get_user_by_email(last_email)
            if user:
                self.current_user = user
                self._show_main()
                return

        self._show_login()

    # ═══════════════════════════════════════════════════════════════════════
    #  Screen Management
    # ═══════════════════════════════════════════════════════════════════════

    def _clear_all(self):
        for widget in self.winfo_children():
            if isinstance(widget, ctk.CTkToplevel):
                continue
            widget.destroy()

    def _show_login(self, prefill_email: str = ""):
        self._clear_all()
        self.login_screen = LoginScreen(
            self,
            on_local_login=self._handle_local_login,
            on_local_register=self._handle_local_register,
            on_google_login=self._handle_google_login,
            google_available=auth.is_google_auth_available(),
            prefill_email=prefill_email,
        )
        self.login_screen.pack(fill="both", expand=True)

    def _show_main(self):
        self._clear_all()

        main_frame = ctk.CTkFrame(self, fg_color="transparent")
        main_frame.pack(fill="both", expand=True)

        self.sidebar = Sidebar(
            main_frame,
            user_info=self.current_user or {"display_name": "User", "email": ""},
            on_new_chat=self._new_chat,
            on_select_chat=self._select_chat,
            on_delete_chat=self._delete_chat,
            on_open_downloads=self._open_downloads,
            on_open_settings=self._open_settings,
            on_logout=self._logout,
        )
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.set_online_status(self.engine.is_online)

        self.chat_screen = ChatScreen(
            main_frame,
            on_send_message=self._send_message,
            on_stop_generation=self._stop_generation,
        )
        self.chat_screen.pack(side="left", fill="both", expand=True)

        model = self.engine.get_active_model() if self.engine.is_online else "offline"
        self.chat_screen.set_model_info(model)
        self.chat_screen.set_mode(self.engine.is_online)
        self._refresh_sessions()

    # ═══════════════════════════════════════════════════════════════════════
    #  Authentication
    # ═══════════════════════════════════════════════════════════════════════

    def _handle_local_login(self, email: str, password: str):
        result = auth.login_local_user(email, password)
        if isinstance(result, str):
            self.login_screen.show_error(result)
        else:
            self.current_user = result
            auth.save_login_session(email)
            self._show_main()

    def _handle_local_register(self, name: str, email: str, password: str):
        result = auth.register_local_user(name, email, password)
        if isinstance(result, str):
            self.login_screen.show_error(result)
        else:
            self.current_user = result
            auth.save_login_session(email)
            self.login_screen.show_success("Account created! Logging in...")
            self.after(500, self._show_main)

    def _handle_google_login(self):
        def on_complete(user):
            if user:
                self.current_user = user
                auth.save_login_session(user.get("email", ""))
                self.after(0, self._show_main)
            else:
                self.after(0, lambda: self.login_screen.show_error(
                    "Google authentication failed. Try local login instead."))

        auth.start_google_oauth(on_complete)

    def _logout(self):
        auth.logout(self.current_user.get("email", "") if self.current_user else "")
        email = self.current_user.get("email", "") if self.current_user else ""
        self.current_user = None
        self.current_session_id = -1
        self._chat_messages = []
        self._show_login(prefill_email=email)

    # ═══════════════════════════════════════════════════════════════════════
    #  Chat Operations
    # ═══════════════════════════════════════════════════════════════════════

    def _new_chat(self):
        if not self.current_user:
            return
        sid = db.create_session(self.current_user["id"], "New Chat")
        self.current_session_id = sid
        self._chat_messages = []
        self.chat_screen.clear_messages()
        self.chat_screen.set_title("New Conversation")
        self.chat_screen._show_welcome()
        self._refresh_sessions()

    def _select_chat(self, session_id: int):
        self.current_session_id = session_id
        self._chat_messages = []

        messages = db.get_session_messages(session_id)
        self.chat_screen.clear_messages()

        if not messages:
            self.chat_screen._show_welcome()
        else:
            for msg in messages:
                self.chat_screen.add_message(
                    msg["role"], msg["content"], msg.get("timestamp", ""))
                self._chat_messages.append({
                    "role": msg["role"], "content": msg["content"]})

        sessions = db.get_user_sessions(self.current_user["id"])
        for s in sessions:
            if s["id"] == session_id:
                self.chat_screen.set_title(s.get("title", "Chat"))
                break
        self._refresh_sessions()

    def _delete_chat(self, session_id: int):
        db.delete_session(session_id)
        if self.current_session_id == session_id:
            self.current_session_id = -1
            self._chat_messages = []
            self.chat_screen.clear_messages()
            self.chat_screen._show_welcome()
            self.chat_screen.set_title("New Conversation")
        self._refresh_sessions()

    def _refresh_sessions(self):
        if self.current_user and self.sidebar:
            sessions = db.get_user_sessions(self.current_user["id"])
            self.sidebar.update_chat_list(sessions, self.current_session_id)

    def _send_message(self, text: str):
        if not text.strip():
            return

        if self.current_session_id <= 0:
            if not self.current_user:
                return
            self.current_session_id = db.create_session(self.current_user["id"], "New Chat")

        if not self._chat_messages:
            self.chat_screen.clear_messages()

        self.chat_screen.add_message("user", text)
        db.add_message(self.current_session_id, "user", text)
        self._chat_messages.append({"role": "user", "content": text})

        if len(self._chat_messages) == 1:
            threading.Thread(target=self._generate_title, args=(text,), daemon=True).start()

        if not self.engine.is_online:
            self.engine.check_connection()
            if not self.engine.is_online:
                self.chat_screen.show_error(
                    "Ollama is not running. Start it with 'ollama serve' in a terminal.")
                return

        offline_ctx = ""
        if self.is_offline_mode:
            offline_ctx = self.kb.get_offline_context()
            if not offline_ctx:
                self.chat_screen.show_error(
                    "No offline data available. Download medical fields first (📥 button in sidebar).")
                return

        self.chat_screen.start_ai_response()
        full_response = []

        def on_token(token):
            full_response.append(token)
            self.after(0, lambda t=token: self.chat_screen.append_to_ai_response(t))

        def on_done(text):
            final = text or "".join(full_response)
            self.after(0, lambda: self._on_response_complete(final))

        def on_error(err):
            self.after(0, lambda: self._on_response_error(err))

        self.engine.chat_stream(
            messages=self._chat_messages, offline_context=offline_ctx,
            on_token=on_token, on_done=on_done, on_error=on_error)

    def _on_response_complete(self, text: str):
        self.chat_screen.finish_ai_response(text)
        db.add_message(self.current_session_id, "assistant", text,
                       model=self.engine.get_active_model())
        self._chat_messages.append({"role": "assistant", "content": text})

    def _on_response_error(self, error: str):
        self.chat_screen.finish_ai_response("")
        self.chat_screen.show_error(error)

    def _stop_generation(self):
        pass

    def _generate_title(self, first_msg: str):
        try:
            title = self.engine.generate_title(first_msg)
            if title and self.current_session_id > 0:
                db.update_session_title(self.current_session_id, title)
                self.after(0, lambda: self.chat_screen.set_title(title))
                self.after(0, self._refresh_sessions)
        except Exception:
            pass

    # ═══════════════════════════════════════════════════════════════════════
    #  Dialogs
    # ═══════════════════════════════════════════════════════════════════════

    def _open_downloads(self):
        user_id = self.current_user["id"] if self.current_user else 0
        DownloadScreen(self, self.kb, self.engine, user_id, db)

    def _open_settings(self):
        SettingsScreen(self, self.engine,
                       on_model_change=self._on_model_change,
                       on_theme_toggle=self._on_theme_toggle)

    def _on_model_change(self, model_name: str):
        self.engine.model = model_name
        if self.chat_screen:
            self.chat_screen.set_model_info(model_name)

    def _on_theme_toggle(self):
        TM.toggle()
        ctk.set_appearance_mode("dark" if TM.is_dark() else "light")
        self._show_main()
        if self.current_session_id > 0:
            self._select_chat(self.current_session_id)
