"""
Settings Screen — Model selection, theme, app configuration
"""
import customtkinter as ctk
from gui.theme import TM, styled_button, styled_label


class SettingsScreen(ctk.CTkToplevel):
    """Settings dialog for model selection, theme, and preferences."""

    def __init__(self, parent, engine, on_model_change, on_theme_toggle):
        super().__init__(parent)
        self.title("⚙️ Settings — MedAI")
        self.geometry("550x580")
        self.configure(fg_color=TM.get("bg_primary"))
        self.resizable(False, False)

        self.engine = engine
        self.on_model_change = on_model_change
        self.on_theme_toggle = on_theme_toggle
        self._build()
        self.grab_set()
        self.focus()

    def _build(self):
        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=20, pady=20)

        # ── Ollama Connection ─────────────────────────────────────────────
        styled_label(scroll, "🔗 Ollama Connection", size=16, weight="bold").pack(anchor="w", pady=(0, 8))

        status_text = "✅ Connected" if self.engine.is_online else "❌ Not Connected"
        status_color = TM.get("success") if self.engine.is_online else TM.get("error")
        styled_label(scroll, status_text, size=13, color=status_color).pack(anchor="w")

        styled_label(
            scroll, f"Host: {self.engine.host}", size=11, color=TM.get("text_muted"),
        ).pack(anchor="w", pady=(4, 12))

        styled_button(
            scroll, "🔄 Refresh Connection",
            command=self._refresh, style="secondary", height=34,
        ).pack(anchor="w", pady=(0, 16))

        # Separator
        ctk.CTkFrame(scroll, height=1, fg_color=TM.get("border")).pack(fill="x", pady=8)

        # ── Model Selection ───────────────────────────────────────────────
        styled_label(scroll, "🤖 AI Model", size=16, weight="bold").pack(anchor="w", pady=(12, 8))

        models = self.engine.available_models if self.engine.available_models else ["(none available)"]
        current = self.engine.get_active_model()

        styled_label(
            scroll, f"Current: {current}", size=12, color=TM.get("text_secondary"),
        ).pack(anchor="w", pady=(0, 8))

        self.model_var = ctk.StringVar(value=current)
        model_menu = ctk.CTkOptionMenu(
            scroll,
            variable=self.model_var,
            values=models,
            command=self._change_model,
            fg_color=TM.get("bg_tertiary"),
            button_color=TM.get("accent"),
            button_hover_color=TM.get("accent_hover"),
            dropdown_fg_color=TM.get("bg_secondary"),
            dropdown_hover_color=TM.get("bg_tertiary"),
            text_color=TM.get("text_primary"),
            dropdown_text_color=TM.get("text_primary"),
            width=300, height=36,
            corner_radius=8,
        )
        model_menu.pack(anchor="w", pady=(0, 8))

        # Pull new model
        styled_label(scroll, "Pull a new model:", size=12, color=TM.get("text_secondary")).pack(anchor="w", pady=(8, 4))

        pull_frame = ctk.CTkFrame(scroll, fg_color="transparent")
        pull_frame.pack(fill="x", pady=(0, 4))

        self.pull_entry = ctk.CTkEntry(
            pull_frame,
            placeholder_text="e.g. llama3.1, mistral, gemma2",
            fg_color=TM.get("input_bg"),
            text_color=TM.get("text_primary"),
            border_color=TM.get("border"),
            border_width=1, height=34, corner_radius=8,
            font=ctk.CTkFont(size=12),
        )
        self.pull_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))

        styled_button(
            pull_frame, "Pull", command=self._pull_model,
            style="primary", width=80, height=34,
        ).pack(side="right")

        self.pull_status = styled_label(scroll, "", size=11, color=TM.get("text_muted"))
        self.pull_status.pack(anchor="w")

        # Separator
        ctk.CTkFrame(scroll, height=1, fg_color=TM.get("border")).pack(fill="x", pady=12)

        # ── Appearance ────────────────────────────────────────────────────
        styled_label(scroll, "🎨 Appearance", size=16, weight="bold").pack(anchor="w", pady=(8, 8))

        theme_text = "🌙 Dark Mode" if TM.is_dark() else "☀️ Light Mode"
        styled_button(
            scroll, f"Toggle Theme (Currently: {theme_text})",
            command=self._toggle_theme, style="secondary", height=36,
        ).pack(anchor="w", pady=(0, 16))

        # Separator
        ctk.CTkFrame(scroll, height=1, fg_color=TM.get("border")).pack(fill="x", pady=8)

        # ── About ─────────────────────────────────────────────────────────
        styled_label(scroll, "ℹ️ About", size=16, weight="bold").pack(anchor="w", pady=(12, 8))
        styled_label(
            scroll, "MedAI v2.0.0 — Medical Intelligence Assistant",
            size=12, color=TM.get("text_secondary"),
        ).pack(anchor="w")
        styled_label(
            scroll, "Powered by Ollama • Local AI • Privacy First",
            size=11, color=TM.get("text_muted"),
        ).pack(anchor="w", pady=(2, 0))
        styled_label(
            scroll, "All medical data is educational only.",
            size=11, color=TM.get("text_muted"),
        ).pack(anchor="w", pady=(2, 16))

        # Close
        styled_button(
            scroll, "Close", command=self.destroy,
            style="secondary", height=36,
        ).pack(anchor="e")

    def _refresh(self):
        self.engine.check_connection()
        self.destroy()
        SettingsScreen(
            self.master, self.engine, self.on_model_change, self.on_theme_toggle
        )

    def _change_model(self, model_name):
        self.engine.model = model_name
        self.on_model_change(model_name)

    def _pull_model(self):
        name = self.pull_entry.get().strip()
        if not name:
            return
        self.pull_status.configure(text=f"Pulling {name}...", text_color=TM.get("info"))

        def on_progress(status):
            try:
                self.pull_status.configure(text=status[:80])
            except Exception:
                pass

        self.engine.pull_model(name, on_progress)

    def _toggle_theme(self):
        self.on_theme_toggle()
        self.destroy()
