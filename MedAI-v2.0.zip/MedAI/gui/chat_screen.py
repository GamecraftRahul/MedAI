"""
Chat Screen — Main conversation UI with streaming responses
"""
import customtkinter as ctk
import time
import textwrap
from gui.theme import TM, styled_button, styled_label


class ChatBubble(ctk.CTkFrame):
    """Individual chat message bubble."""

    def __init__(self, parent, role: str, content: str, timestamp: str = ""):
        is_user = role == "user"
        bg = TM.get("user_bubble") if is_user else TM.get("ai_bubble")
        super().__init__(parent, fg_color=bg, corner_radius=16)

        self.content_var = content
        inner = ctk.CTkFrame(self, fg_color="transparent")
        inner.pack(fill="x", padx=16, pady=12)

        # Role label
        role_text = "You" if is_user else "🏥 MedAI"
        role_color = TM.get("info") if is_user else TM.get("accent")
        styled_label(inner, role_text, size=11, weight="bold", color=role_color).pack(anchor="w")

        # Message content
        self.content_label = ctk.CTkLabel(
            inner,
            text=content,
            text_color=TM.get("text_primary"),
            font=ctk.CTkFont(family="Segoe UI", size=13),
            wraplength=600,
            justify="left",
            anchor="w",
        )
        self.content_label.pack(anchor="w", pady=(4, 0), fill="x")

        # Timestamp
        if timestamp:
            styled_label(
                inner, timestamp, size=10, color=TM.get("text_muted"),
            ).pack(anchor="e", pady=(6, 0))

    def update_content(self, text: str):
        self.content_var = text
        self.content_label.configure(text=text)


class ChatScreen(ctk.CTkFrame):
    """Main chat area with message history and input."""

    def __init__(self, parent, on_send_message, on_stop_generation):
        super().__init__(parent, fg_color=TM.get("bg_chat"), corner_radius=0)

        self.on_send_message = on_send_message
        self.on_stop_generation = on_stop_generation
        self._is_generating = False
        self._current_ai_bubble: ChatBubble = None

        self._build()

    def _build(self):
        # ── Header ────────────────────────────────────────────────────────
        header = ctk.CTkFrame(self, fg_color=TM.get("bg_secondary"), height=56, corner_radius=0)
        header.pack(fill="x")
        header.pack_propagate(False)

        header_inner = ctk.CTkFrame(header, fg_color="transparent")
        header_inner.pack(fill="x", padx=20, pady=10)

        self.title_label = styled_label(
            header_inner, "💬 New Conversation", size=16, weight="bold",
        )
        self.title_label.pack(side="left")

        self.model_label = styled_label(
            header_inner, "Model: loading...", size=11, color=TM.get("text_muted"),
        )
        self.model_label.pack(side="right")

        self.mode_label = styled_label(
            header_inner, "🟢 Online", size=11, color=TM.get("success"),
        )
        self.mode_label.pack(side="right", padx=(0, 16))

        # ── Messages area ─────────────────────────────────────────────────
        self.messages_frame = ctk.CTkScrollableFrame(
            self, fg_color="transparent",
            scrollbar_button_color=TM.get("scrollbar"),
            scrollbar_button_hover_color=TM.get("scrollbar_hover"),
        )
        self.messages_frame.pack(fill="both", expand=True, padx=0, pady=0)

        # Welcome message
        self._show_welcome()

        # ── Input area ────────────────────────────────────────────────────
        input_frame = ctk.CTkFrame(self, fg_color=TM.get("bg_secondary"), corner_radius=0)
        input_frame.pack(fill="x", side="bottom")

        input_inner = ctk.CTkFrame(input_frame, fg_color="transparent")
        input_inner.pack(fill="x", padx=20, pady=14)

        # Disclaimer
        styled_label(
            input_inner,
            "⚠️ MedAI provides educational info only. Always consult a healthcare professional.",
            size=10, color=TM.get("text_muted"),
        ).pack(anchor="w", pady=(0, 8))

        # Input row
        input_row = ctk.CTkFrame(input_inner, fg_color="transparent")
        input_row.pack(fill="x")

        self.input_entry = ctk.CTkTextbox(
            input_row,
            fg_color=TM.get("input_bg"),
            text_color=TM.get("text_primary"),
            border_color=TM.get("border"),
            border_width=1,
            corner_radius=12,
            height=50,
            font=ctk.CTkFont(family="Segoe UI", size=13),
            wrap="word",
        )
        self.input_entry.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self.input_entry.bind("<Return>", self._on_enter)
        self.input_entry.bind("<Shift-Return>", self._on_shift_enter)

        # Send / Stop button
        self.send_btn = styled_button(
            input_row, "➤ Send", command=self._on_send,
            style="primary", width=100, height=50,
        )
        self.send_btn.pack(side="right")

        # Quick suggestion buttons
        self._add_suggestions(input_inner)

    def _add_suggestions(self, parent):
        sug_frame = ctk.CTkFrame(parent, fg_color="transparent")
        sug_frame.pack(fill="x", pady=(8, 0))

        suggestions = [
            "What causes diabetes?",
            "Explain antibiotics",
            "COVID-19 variants",
            "Heart attack symptoms",
        ]
        for s in suggestions:
            btn = ctk.CTkButton(
                sug_frame,
                text=s,
                command=lambda t=s: self._use_suggestion(t),
                fg_color=TM.get("bg_tertiary"),
                hover_color=TM.get("border_light"),
                text_color=TM.get("text_secondary"),
                height=28,
                corner_radius=14,
                font=ctk.CTkFont(size=11),
                border_width=1,
                border_color=TM.get("border"),
            )
            btn.pack(side="left", padx=(0, 6))

    def _show_welcome(self):
        welcome = ctk.CTkFrame(self.messages_frame, fg_color="transparent")
        welcome.pack(expand=True, fill="both", pady=40)

        center = ctk.CTkFrame(welcome, fg_color="transparent")
        center.pack(expand=True)

        styled_label(center, "🏥", size=64).pack(pady=(20, 8))
        styled_label(
            center, "Welcome to MedAI", size=28, weight="bold", color=TM.get("accent"),
        ).pack(pady=(0, 8))
        styled_label(
            center,
            "Your AI-powered Medical Knowledge Assistant",
            size=14, color=TM.get("text_secondary"),
        ).pack(pady=(0, 16))

        # Feature cards
        features = [
            ("🦠", "Diseases & Conditions", "Every known disease, from common to rare"),
            ("💊", "Pharmacology", "Drug information, interactions, and mechanisms"),
            ("🔬", "Diagnostics", "Lab tests, imaging, and clinical decision-making"),
            ("🧬", "Medical Science", "Anatomy, physiology, genetics, and more"),
        ]

        cards_frame = ctk.CTkFrame(center, fg_color="transparent")
        cards_frame.pack(pady=8)

        for i, (icon, title, desc) in enumerate(features):
            card = ctk.CTkFrame(
                cards_frame, fg_color=TM.get("bg_tertiary"), corner_radius=12,
                border_width=1, border_color=TM.get("border"),
            )
            card.grid(row=i // 2, column=i % 2, padx=8, pady=8, sticky="nsew")

            card_inner = ctk.CTkFrame(card, fg_color="transparent")
            card_inner.pack(padx=16, pady=12)

            styled_label(card_inner, f"{icon} {title}", size=14, weight="bold").pack(anchor="w")
            styled_label(card_inner, desc, size=11, color=TM.get("text_secondary")).pack(anchor="w")

    def set_title(self, title: str):
        self.title_label.configure(text=f"💬 {title}")

    def set_model_info(self, model: str):
        self.model_label.configure(text=f"Model: {model}")

    def set_mode(self, online: bool):
        if online:
            self.mode_label.configure(text="🟢 Online", text_color=TM.get("success"))
        else:
            self.mode_label.configure(text="🟡 Offline", text_color=TM.get("warning"))

    def clear_messages(self):
        for widget in self.messages_frame.winfo_children():
            widget.destroy()

    def add_message(self, role: str, content: str, timestamp: str = ""):
        bubble = ChatBubble(self.messages_frame, role, content, timestamp)
        bubble.pack(
            fill="x",
            padx=(60 if role == "user" else 20, 20 if role == "user" else 60),
            pady=6,
            anchor="e" if role == "user" else "w",
        )
        self._scroll_bottom()
        return bubble

    def start_ai_response(self):
        """Create an empty AI bubble for streaming."""
        self._is_generating = True
        self.send_btn.configure(text="⬛ Stop", command=self._on_stop)
        self._current_ai_bubble = self.add_message("assistant", "▌")
        return self._current_ai_bubble

    def append_to_ai_response(self, token: str):
        """Add a token to the current streaming response."""
        if self._current_ai_bubble:
            current = self._current_ai_bubble.content_var
            if current == "▌":
                current = ""
            current += token
            self._current_ai_bubble.update_content(current + "▌")
            self._scroll_bottom()

    def finish_ai_response(self, final_text: str = None):
        """Finalize the streaming response."""
        self._is_generating = False
        self.send_btn.configure(text="➤ Send", command=self._on_send)
        if self._current_ai_bubble:
            if final_text:
                self._current_ai_bubble.update_content(final_text)
            else:
                current = self._current_ai_bubble.content_var.rstrip("▌")
                self._current_ai_bubble.update_content(current)
        self._current_ai_bubble = None

    def show_error(self, msg: str):
        """Show an error message in the chat."""
        error_frame = ctk.CTkFrame(
            self.messages_frame,
            fg_color=TM.get("error") + "22",
            corner_radius=12,
            border_width=1,
            border_color=TM.get("error"),
        )
        error_frame.pack(fill="x", padx=40, pady=8)
        styled_label(
            error_frame, f"⚠️ {msg}", size=12, color=TM.get("error"),
        ).pack(padx=16, pady=10)
        self._scroll_bottom()

    def _on_send(self):
        text = self.input_entry.get("1.0", "end-1c").strip()
        if text and not self._is_generating:
            self.input_entry.delete("1.0", "end")
            self.on_send_message(text)

    def _on_stop(self):
        self._is_generating = False
        self.on_stop_generation()
        self.send_btn.configure(text="➤ Send", command=self._on_send)

    def _on_enter(self, event):
        if not event.state & 1:  # Not Shift
            self._on_send()
            return "break"

    def _on_shift_enter(self, event):
        return  # Allow newline

    def _use_suggestion(self, text: str):
        if not self._is_generating:
            self.on_send_message(text)

    def _scroll_bottom(self):
        self.messages_frame._parent_canvas.yview_moveto(1.0)
