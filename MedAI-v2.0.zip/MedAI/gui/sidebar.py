"""
Sidebar — Chat history, navigation, user profile
"""
import customtkinter as ctk
from gui.theme import TM, styled_button, styled_label


class Sidebar(ctk.CTkFrame):
    """Left sidebar: user info, new chat, chat history, settings."""

    def __init__(self, parent, user_info: dict, on_new_chat, on_select_chat,
                 on_delete_chat, on_open_downloads, on_open_settings, on_logout):
        super().__init__(parent, fg_color=TM.get("sidebar"), width=280, corner_radius=0)
        self.pack_propagate(False)

        self.user_info = user_info
        self.on_new_chat = on_new_chat
        self.on_select_chat = on_select_chat
        self.on_delete_chat = on_delete_chat
        self.on_open_downloads = on_open_downloads
        self.on_open_settings = on_open_settings
        self.on_logout = on_logout

        self._chat_buttons: dict[int, ctk.CTkButton] = {}
        self._active_session_id: int = -1
        self._build()

    def _build(self):
        # ── Header with user info ─────────────────────────────────────────
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=16, pady=(16, 8))

        top_row = ctk.CTkFrame(header, fg_color="transparent")
        top_row.pack(fill="x")

        styled_label(
            top_row, "🏥", size=22
        ).pack(side="left")

        styled_label(
            top_row, " MedAI", size=18, weight="bold",
            color=TM.get("accent"),
        ).pack(side="left", padx=(4, 0))

        # Online/Offline indicator
        self.status_dot = styled_label(
            top_row, "●", size=12, color=TM.get("success"),
        )
        self.status_dot.pack(side="right")

        # User info
        user_frame = ctk.CTkFrame(header, fg_color=TM.get("bg_tertiary"), corner_radius=10)
        user_frame.pack(fill="x", pady=(12, 0))

        user_inner = ctk.CTkFrame(user_frame, fg_color="transparent")
        user_inner.pack(fill="x", padx=12, pady=10)

        name = self.user_info.get("display_name", "Offline User")
        email = self.user_info.get("email", "offline@local")

        styled_label(user_inner, name[:25], size=13, weight="bold").pack(anchor="w")
        styled_label(user_inner, email[:30], size=11, color=TM.get("text_muted")).pack(anchor="w")

        # ── New Chat button ───────────────────────────────────────────────
        styled_button(
            self, "＋  New Chat", command=self.on_new_chat,
            style="primary", width=248, height=40,
        ).pack(padx=16, pady=(12, 8))

        # ── Search ────────────────────────────────────────────────────────
        self.search_entry = ctk.CTkEntry(
            self,
            placeholder_text="🔍 Search chats...",
            fg_color=TM.get("bg_tertiary"),
            text_color=TM.get("text_primary"),
            placeholder_text_color=TM.get("text_muted"),
            border_width=0, height=34, corner_radius=8,
            font=ctk.CTkFont(size=12),
        )
        self.search_entry.pack(fill="x", padx=16, pady=(0, 8))
        self.search_entry.bind("<KeyRelease>", self._on_search)

        # ── Chat history label ────────────────────────────────────────────
        styled_label(
            self, "CHAT HISTORY", size=10, weight="bold",
            color=TM.get("text_muted"),
        ).pack(anchor="w", padx=20, pady=(8, 4))

        # ── Scrollable chat list ──────────────────────────────────────────
        self.chat_list_frame = ctk.CTkScrollableFrame(
            self, fg_color="transparent",
            scrollbar_button_color=TM.get("scrollbar"),
            scrollbar_button_hover_color=TM.get("scrollbar_hover"),
        )
        self.chat_list_frame.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        # ── Bottom buttons ────────────────────────────────────────────────
        bottom = ctk.CTkFrame(self, fg_color="transparent")
        bottom.pack(fill="x", padx=12, pady=(0, 12))

        btn_row1 = ctk.CTkFrame(bottom, fg_color="transparent")
        btn_row1.pack(fill="x", pady=(0, 4))

        styled_button(
            btn_row1, "📥 Download Data",
            command=self.on_open_downloads, style="secondary", height=34,
        ).pack(fill="x")

        btn_row2 = ctk.CTkFrame(bottom, fg_color="transparent")
        btn_row2.pack(fill="x", pady=(0, 4))

        styled_button(
            btn_row2, "⚙️ Settings",
            command=self.on_open_settings, style="ghost", height=32,
        ).pack(side="left", expand=True, fill="x", padx=(0, 4))

        styled_button(
            btn_row2, "🚪 Logout",
            command=self.on_logout, style="ghost", height=32,
        ).pack(side="right", expand=True, fill="x", padx=(4, 0))

    def update_chat_list(self, sessions: list, active_id: int = -1):
        """Refresh the chat list."""
        self._active_session_id = active_id

        # Clear existing
        for widget in self.chat_list_frame.winfo_children():
            widget.destroy()
        self._chat_buttons.clear()

        if not sessions:
            styled_label(
                self.chat_list_frame, "No conversations yet",
                size=12, color=TM.get("text_muted"),
            ).pack(pady=20)
            return

        for session in sessions:
            sid = session["id"]
            title = session.get("title", "New Chat")
            is_active = sid == active_id

            btn_frame = ctk.CTkFrame(
                self.chat_list_frame,
                fg_color=TM.get("accent_dim") if is_active else "transparent",
                corner_radius=8,
            )
            btn_frame.pack(fill="x", pady=1)

            inner = ctk.CTkFrame(btn_frame, fg_color="transparent")
            inner.pack(fill="x", padx=4, pady=4)

            chat_btn = ctk.CTkButton(
                inner,
                text=f"💬 {title[:28]}",
                command=lambda s=sid: self.on_select_chat(s),
                fg_color="transparent",
                hover_color=TM.get("bg_tertiary"),
                text_color=TM.get("accent") if is_active else TM.get("text_primary"),
                anchor="w",
                height=30,
                font=ctk.CTkFont(size=12, weight="bold" if is_active else "normal"),
            )
            chat_btn.pack(side="left", fill="x", expand=True)

            del_btn = ctk.CTkButton(
                inner,
                text="✕",
                command=lambda s=sid: self.on_delete_chat(s),
                fg_color="transparent",
                hover_color=TM.get("error"),
                text_color=TM.get("text_muted"),
                width=28, height=28,
                corner_radius=14,
                font=ctk.CTkFont(size=11),
            )
            del_btn.pack(side="right")

            self._chat_buttons[sid] = chat_btn

    def set_online_status(self, is_online: bool):
        color = TM.get("success") if is_online else TM.get("warning")
        self.status_dot.configure(text_color=color)

    def _on_search(self, event=None):
        query = self.search_entry.get().lower().strip()
        for sid, btn in self._chat_buttons.items():
            text = btn.cget("text").lower()
            parent = btn.master.master
            if query == "" or query in text:
                parent.pack(fill="x", pady=1)
            else:
                parent.pack_forget()
