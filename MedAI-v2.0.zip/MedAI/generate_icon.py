"""Generate a simple app icon for MedAI."""
try:
    from PIL import Image, ImageDraw, ImageFont
    import os

    sizes = [256]
    for size in sizes:
        img = Image.new("RGBA", (size, size), (15, 17, 23, 255))
        draw = ImageDraw.Draw(img)

        # Draw a circle background
        margin = size // 8
        draw.ellipse(
            [margin, margin, size - margin, size - margin],
            fill=(0, 212, 170, 255),
        )

        # Draw a cross/plus symbol
        cx, cy = size // 2, size // 2
        arm = size // 6
        thick = size // 10
        draw.rectangle(
            [cx - thick, cy - arm, cx + thick, cy + arm],
            fill=(15, 17, 23, 255),
        )
        draw.rectangle(
            [cx - arm, cy - thick, cx + arm, cy + thick],
            fill=(15, 17, 23, 255),
        )

        out_path = os.path.join(os.path.dirname(__file__), "assets", "icon.png")
        img.save(out_path)
        print(f"Icon saved: {out_path}")

        # Try to save .ico too
        try:
            ico_path = os.path.join(os.path.dirname(__file__), "assets", "icon.ico")
            img.save(ico_path, format="ICO", sizes=[(256, 256)])
            print(f"ICO saved: {ico_path}")
        except Exception as e:
            print(f"Could not create .ico: {e}")

except ImportError:
    print("Pillow not available, skipping icon generation.")
    print("Install with: pip install Pillow")

if __name__ == "__main__":
    pass
