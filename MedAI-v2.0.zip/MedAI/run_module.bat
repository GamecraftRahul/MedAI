@echo off
setlocal EnableDelayedExpansion
title MedAI - Medical Intelligence Assistant
color 0B
cls

echo.
echo  ****************************************************************
echo  *     MedAI - Medical Intelligence Assistant v2.0              *
echo  ****************************************************************
echo.

:: CHECK SETUP
if not exist "venv\Scripts\activate.bat" (
    echo  ERROR: MedAI has not been set up yet.
    echo  Please run setup.bat first to install everything.
    echo.
    pause
    exit /b 1
)

if not exist "venv\Scripts\python.exe" (
    echo  ERROR: Virtual environment is broken.
    echo  Delete the "venv" folder and run setup.bat again.
    echo.
    pause
    exit /b 1
)

:: ACTIVATE PYTHON
echo  [1/3] Activating Python environment...
call venv\Scripts\activate.bat
echo        Done.
echo.

:: START OLLAMA
echo  [2/3] Starting Ollama AI service...

curl -s http://localhost:11434/api/tags >nul 2>&1
if !errorlevel! equ 0 (
    echo        Ollama is already running.
) else (
    where ollama >nul 2>&1
    if !errorlevel! equ 0 (
        echo        Starting Ollama in background...
        start /min "OllamaService" ollama serve
        set TRIES=0
        :waitloop
        timeout /t 2 /nobreak >nul
        curl -s http://localhost:11434/api/tags >nul 2>&1
        if !errorlevel! equ 0 (
            echo        Ollama started successfully.
            goto ollamaok
        )
        set /a TRIES+=1
        if !TRIES! lss 7 goto waitloop
        echo        WARNING: Ollama did not start in time.
        echo        The app will open but AI chat needs Ollama running.
    ) else (
        echo        WARNING: Ollama not found on this system.
        echo        Install from: https://ollama.com/download
        echo        Then run: ollama pull llama3.1
    )
)
:ollamaok
echo.

:: LAUNCH APP
echo  [3/3] Launching MedAI GUI...
echo  ------------------------------------------------
echo.
echo  The app window will open shortly.
echo  Keep this terminal open while using MedAI.
echo  Close this terminal to quit the app.
echo.

python main.py

echo.
echo  ------------------------------------------------
echo  MedAI has been closed.
echo.
pause
