@echo off
setlocal EnableDelayedExpansion
title MedAI - Build Windows Installer
color 0D
cls

echo.
echo  ****************************************************************
echo  *     MedAI - Create Windows Installer (.exe setup)            *
echo  ****************************************************************
echo.
echo  This script will:
echo    1. Build the standalone .exe via PyInstaller
echo    2. Create a Windows installer via Inno Setup (if installed)
echo    3. Create a portable ZIP package
echo.
echo  Press any key to begin...
pause >nul
echo.

:: STEP 1: Build EXE
echo  [STEP 1] Building standalone application...
echo  ------------------------------------------------
call build_exe.bat

if not exist "dist\MedAI\MedAI.exe" (
    echo  ERROR: EXE build failed. Cannot continue.
    pause
    exit /b 1
)
echo.

:: STEP 2: Check for Inno Setup
echo  [STEP 2] Checking for Inno Setup Compiler...
echo  ------------------------------------------------

set "ISCC="

if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" (
    set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
)

if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" (
    set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
)

if "!ISCC!"=="" (
    echo.
    echo  Inno Setup not found on this computer.
    echo  To create a proper installer .exe:
    echo    1. Download Inno Setup from: https://jrsoftware.org/isdl.php
    echo    2. Install it
    echo    3. Run this script again
    echo.
    echo  For now, share the portable ZIP instead:
    echo    dist\MedAI-Portable.zip
    echo.
    pause
    exit /b 0
)

:: STEP 3: Build Installer
echo  [STEP 3] Building Windows Installer...
echo  ------------------------------------------------
echo.

if not exist "installer_output" mkdir "installer_output"

"!ISCC!" installer.iss

if !errorlevel! neq 0 (
    echo.
    echo  Installer build failed. Check errors above.
    echo  You can still share: dist\MedAI-Portable.zip
    pause
    exit /b 1
)

echo.
echo  ****************************************************************
echo  *                  ALL BUILDS COMPLETE!                         *
echo  ****************************************************************
echo.
echo  PORTABLE version:
echo    dist\MedAI-Portable.zip
echo.
echo  INSTALLER version:
echo    installer_output\MedAI_Setup_v2.0.exe
echo.
echo  To install on another computer:
echo    1. Copy the installer .exe or ZIP to the other PC
echo    2. They install Ollama from ollama.com/download
echo    3. They run: ollama pull llama3.1
echo    4. They run the installer or extract the ZIP
echo    5. Launch MedAI!
echo.
pause
