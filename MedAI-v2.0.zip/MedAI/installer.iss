; ════════════════════════════════════════════════════════════════
; MedAI — Inno Setup Installer Script
; Creates a professional Windows installer (.exe)
;
; HOW TO USE:
;   1. First run build_exe.bat to create dist\MedAI\ folder
;   2. Install Inno Setup from: https://jrsoftware.org/isdl.php
;   3. Open this .iss file in Inno Setup Compiler
;   4. Click Build > Compile
;   5. The installer will be in the "installer_output" folder
; ════════════════════════════════════════════════════════════════

[Setup]
AppName=MedAI - Medical Intelligence Assistant
AppVersion=2.0.0
AppPublisher=MedAI
AppPublisherURL=https://github.com/medai
DefaultDirName={autopf}\MedAI
DefaultGroupName=MedAI
UninstallDisplayIcon={app}\MedAI.exe
OutputDir=installer_output
OutputBaseFilename=MedAI_Setup_v2.0
Compression=lzma2
SolidCompression=yes
SetupIconFile=assets\icon.ico
WizardStyle=modern
PrivilegesRequired=lowest
DisableProgramGroupPage=yes
LicenseFile=
InfoBeforeFile=

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a Desktop shortcut"; GroupDescription: "Additional shortcuts:"
Name: "startmenu"; Description: "Create a Start Menu shortcut"; GroupDescription: "Additional shortcuts:"; Flags: checkedonce

[Files]
; Main application files from PyInstaller dist
Source: "dist\MedAI\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

; Ensure data directories exist
Source: "data\medical_fields\.gitkeep"; DestDir: "{app}\data\medical_fields"; Flags: ignoreversion
Source: "auth\client_secret.json.template"; DestDir: "{app}\auth"; Flags: ignoreversion

[Dirs]
Name: "{app}\data\medical_fields"
Name: "{app}\data\database"
Name: "{app}\data\cache"
Name: "{app}\auth\tokens"
Name: "{app}\assets"

[Icons]
Name: "{group}\MedAI"; Filename: "{app}\MedAI.exe"
Name: "{group}\Uninstall MedAI"; Filename: "{uninstallexe}"
Name: "{autodesktop}\MedAI"; Filename: "{app}\MedAI.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\MedAI.exe"; Description: "Launch MedAI"; Flags: nowait postinstall skipifsilent

[Messages]
WelcomeLabel1=Welcome to MedAI Setup
WelcomeLabel2=This will install MedAI — Medical Intelligence Assistant on your computer.%n%nIMPORTANT: You also need Ollama installed separately.%nDownload from: https://ollama.com/download%n%nAfter installing, run: ollama pull llama3.1

[Code]
// Show a reminder after installation
procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
  begin
    MsgBox(
      'MedAI installed successfully!' + #13#10 + #13#10 +
      'NEXT STEPS:' + #13#10 +
      '1. Install Ollama from: https://ollama.com/download' + #13#10 +
      '2. Open Command Prompt and run: ollama pull llama3.1' + #13#10 +
      '3. Launch MedAI from your Desktop or Start Menu' + #13#10 + #13#10 +
      'First time? Click Register to create your account.',
      mbInformation, MB_OK
    );
  end;
end;
