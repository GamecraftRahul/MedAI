# 🏥 MedAI — Medical Intelligence Assistant

> **Your AI-Powered Local Medical Knowledge Assistant**
> Powered by Ollama • Local AI • Privacy First

---

## ✨ Features

### 🤖 AI-Powered Medical Knowledge
- Covers **ALL medical specialties**: Cardiology, Neurology, Oncology, Pharmacology, Microbiology, Surgery, and 15+ more
- Information on **every known disease**, bacteria, virus, drug, and medical procedure
- Evidence-based responses with medical terminology explained
- Educational disclaimers included automatically

### 🔐 Google OAuth Authentication
- Secure sign-in with your Google/Gmail account
- Per-user chat history saved locally
- Auto-login on return visits
- Offline mode available without Google account

### 💬 Chat System
- Full conversation history saved per user
- Multiple chat sessions with auto-generated titles
- Search across all your conversations
- Stream AI responses in real-time

### 📥 Offline Mode with Downloadable Data
- **20 medical sub-fields** available for download
- AI-generated comprehensive knowledge bases
- Works without internet after download
- Choose exactly which fields you need

### 🎨 Beautiful Local GUI
- Modern dark/light theme (CustomTkinter)
- Runs natively on your desktop — no browser needed
- Responsive layout with sidebar navigation
- Quick suggestion buttons for common queries

---

## 🚀 Quick Start

### Prerequisites
1. **Python 3.10+** — [Download](https://python.org)
2. **Ollama** — [Download](https://ollama.com/download)
3. **Git** (optional) — for cloning

### Installation

```bash
# 1. Clone or download the project
cd MedAI

# 2. Run the setup script (Windows)
setup.bat

# 3. Start the application
run_module.bat
```

### Manual Installation (Alternative)

```bash
# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Pull an AI model
ollama pull llama3.1

# Run
python main.py
```

---

## 🔑 Google OAuth Setup

To enable Google sign-in:

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a new project (or select existing)
3. Navigate to **APIs & Services** → **Library**
4. Enable **Google People API**
5. Go to **Credentials** → **Create Credentials** → **OAuth 2.0 Client ID**
6. Application type: **Desktop app**
7. Download the JSON file
8. Rename to `client_secret.json`
9. Place in the `auth/` folder

> **Without Google OAuth**, you can still use MedAI in **Offline Mode**.

---

## 📁 Project Structure

```
MedAI/
├── main.py                  # Entry point
├── config.py                # All configuration
├── requirements.txt         # Python dependencies
├── setup.bat                # Windows setup script
├── run_module.bat           # Windows run script
│
├── auth/                    # Authentication
│   ├── __init__.py          # Google OAuth implementation
│   ├── client_secret.json   # (You provide this)
│   └── tokens/              # Saved auth tokens
│
├── core/                    # AI Engine
│   └── __init__.py          # Ollama engine + Medical KB
│
├── database/                # Data Layer
│   └── __init__.py          # SQLite operations
│
├── gui/                     # User Interface
│   ├── __init__.py
│   ├── app.py               # Main app orchestrator
│   ├── theme.py             # Theme & styling utilities
│   ├── login_screen.py      # Login UI
│   ├── chat_screen.py       # Chat interface
│   ├── sidebar.py           # Sidebar navigation
│   ├── download_screen.py   # Data download manager
│   └── settings_screen.py   # Settings dialog
│
├── data/
│   ├── database/            # SQLite database files
│   ├── medical_fields/      # Downloaded knowledge JSONs
│   └── cache/               # Temporary cache
│
└── assets/                  # Icons, images
```

---

## 📥 Downloadable Medical Fields

| # | Field | Icon | Topics |
|---|-------|------|--------|
| 1 | Anatomy & Physiology | 🫀 | Body systems, organs, cells |
| 2 | Pharmacology & Drugs | 💊 | Drug classes, interactions, dosages |
| 3 | Microbiology | 🦠 | Bacteria, viruses, fungi, parasites |
| 4 | Pathology & Diseases | 🔬 | Disease mechanisms, classification |
| 5 | Surgery & Procedures | 🏥 | Surgical techniques, care |
| 6 | Cardiology | ❤️ | Heart diseases, ECG, procedures |
| 7 | Neurology | 🧠 | Brain, nervous system disorders |
| 8 | Oncology & Cancer | 🎗️ | Cancer types, treatments |
| 9 | Pediatrics | 👶 | Child health, development |
| 10 | Psychiatry | 🧘 | Mental health, therapies |
| 11 | Emergency Medicine | 🚑 | Trauma, acute care, protocols |
| 12 | Dermatology | 🩹 | Skin conditions, treatments |
| 13 | Orthopedics | 🦴 | Bones, joints, musculoskeletal |
| 14 | Endocrinology | ⚗️ | Hormones, diabetes, thyroid |
| 15 | Immunology & Allergy | 🛡️ | Immune system, autoimmune |
| 16 | Public Health | 📊 | Epidemiology, prevention |
| 17 | Radiology & Imaging | 📡 | X-ray, MRI, CT interpretation |
| 18 | Genetics & Genomics | 🧬 | Genetic disorders, gene therapy |
| 19 | Nutrition & Dietetics | 🥗 | Clinical nutrition, dietary therapy |
| 20 | First Aid & Basic Care | 🩺 | Emergency first aid, CPR |

---

## 🤖 Supported Ollama Models

Any Ollama model works. Recommended:

| Model | Size | Best For |
|-------|------|----------|
| `llama3.1` | ~4.7GB | General medical queries (recommended) |
| `llama3.1:70b` | ~40GB | Deep/complex medical analysis |
| `mistral` | ~4.1GB | Fast responses |
| `gemma2` | ~5.4GB | Good medical comprehension |
| `phi3` | ~2.3GB | Lightweight option |
| `meditron` | ~4GB | Specialized medical model |

Pull a model: `ollama pull llama3.1`

---

## ⚠️ Important Disclaimer

**MedAI is an educational tool ONLY.** It is NOT a substitute for professional medical advice, diagnosis, or treatment. Always consult qualified healthcare professionals for medical decisions.

---

## 🛠️ Troubleshooting

**Ollama won't connect:**
- Run `ollama serve` in a terminal
- Check if port 11434 is available
- Try `curl http://localhost:11434/api/tags`

**Google login fails:**
- Verify `client_secret.json` is in `auth/` folder
- Check the redirect URI includes `http://localhost:8491`
- Ensure Google People API is enabled

**GUI looks wrong:**
- Update CustomTkinter: `pip install --upgrade customtkinter`
- Try toggling dark/light mode in Settings

**Model responses are slow:**
- Use a smaller model (phi3, mistral)
- Ensure enough RAM (8GB+ recommended)
- Close other heavy applications

---

## 📄 License

This project is for educational and personal use.
