@echo off
setlocal EnableDelayedExpansion
title MedAI - Build Executable
color 0E
cls

echo.
echo  ****************************************************************
echo  *     MedAI - Build Standalone Executable (.exe)               *
echo  ****************************************************************
echo.
echo  This will create a portable MedAI.exe that you can share.
echo  NOTE: Recipients still need Ollama from https://ollama.com
echo.
echo  Press any key to start building...
pause >nul
echo.

:: CHECK VENV
if not exist "venv\Scripts\activate.bat" (
    echo  ERROR: Run setup.bat first!
    pause
    exit /b 1
)

call venv\Scripts\activate.bat

:: INSTALL PYINSTALLER
echo  [1/4] Installing PyInstaller...
pip install pyinstaller >nul 2>&1
echo        Done.
echo.

:: GENERATE ICON
echo  [2/4] Generating app icon...
python generate_icon.py 2>nul
echo        Done.
echo.

:: BUILD EXE
echo  [3/4] Building executable... This takes 2-5 minutes.
echo  ------------------------------------------------
echo.

pyinstaller --name "MedAI" --windowed --noconfirm --clean --add-data "assets;assets" --hidden-import customtkinter --hidden-import PIL --hidden-import PIL._tkinter_finder --hidden-import requests --hidden-import sqlite3 --hidden-import ollama --hidden-import google.auth --hidden-import google_auth_oauthlib main.py

echo.

:: CHECK BUILD
set "DIST_DIR=dist\MedAI"

if not exist "%DIST_DIR%\MedAI.exe" (
    echo  ERROR: Build failed. Check errors above.
    pause
    exit /b 1
)

:: CREATE DISTRIBUTABLE
echo  [4/4] Creating distributable package...

if not exist "%DIST_DIR%\data\medical_fields" mkdir "%DIST_DIR%\data\medical_fields"
if not exist "%DIST_DIR%\data\database" mkdir "%DIST_DIR%\data\database"
if not exist "%DIST_DIR%\data\cache" mkdir "%DIST_DIR%\data\cache"
if not exist "%DIST_DIR%\auth" mkdir "%DIST_DIR%\auth"
if not exist "%DIST_DIR%\auth\tokens" mkdir "%DIST_DIR%\auth\tokens"
if not exist "%DIST_DIR%\assets" mkdir "%DIST_DIR%\assets"

xcopy /s /y "assets\*" "%DIST_DIR%\assets\" >nul 2>&1
copy "auth\client_secret.json.template" "%DIST_DIR%\auth\" >nul 2>&1

:: Create launcher script using a temp approach to avoid parenthesis issues
echo @echo off > "%DIST_DIR%\Start_MedAI.bat"
echo title MedAI >> "%DIST_DIR%\Start_MedAI.bat"
echo curl -s http://localhost:11434/api/tags ^>nul 2^>^&1 >> "%DIST_DIR%\Start_MedAI.bat"
echo if %%errorlevel%% neq 0 start /min "Ollama" ollama serve >> "%DIST_DIR%\Start_MedAI.bat"
echo timeout /t 3 /nobreak ^>nul >> "%DIST_DIR%\Start_MedAI.bat"
echo start "" "MedAI.exe" >> "%DIST_DIR%\Start_MedAI.bat"

:: Create install instructions
echo MedAI - Installation Guide> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo ================================>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo.>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo STEP 1: Install Ollama>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo   Go to: https://ollama.com/download>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo   Download and install Ollama for Windows>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo.>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo STEP 2: Download AI Model>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo   Open Command Prompt and run:>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo   ollama pull llama3.1>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo   (This downloads about 4.7 GB)>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo.>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo STEP 3: Run MedAI>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo   Double-click Start_MedAI.bat or MedAI.exe>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo.>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo STEP 4: Create Your Account>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo   Click Register on the login screen>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo   Enter name, email, password>> "%DIST_DIR%\HOW_TO_INSTALL.txt"
echo   Start chatting!>> "%DIST_DIR%\HOW_TO_INSTALL.txt"

:: Create ZIP
echo  Creating ZIP package...
powershell -Command "Compress-Archive -Path '%DIST_DIR%\*' -DestinationPath 'dist\MedAI-Portable.zip' -Force" 2>nul

echo.
echo  ****************************************************************
echo  *                   BUILD COMPLETE!                             *
echo  ****************************************************************
echo.
echo  Files created:
echo    dist\MedAI\MedAI.exe        - Main executable
echo    dist\MedAI\Start_MedAI.bat  - Easy launcher
echo    dist\MedAI-Portable.zip     - ZIP to share with others
echo.
echo  To share with someone:
echo    1. Give them dist\MedAI-Portable.zip
echo    2. They extract it to any folder
echo    3. They install Ollama from ollama.com/download
echo    4. They run: ollama pull llama3.1
echo    5. They double-click Start_MedAI.bat
echo.
pause
