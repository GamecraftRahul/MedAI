# -*- mode: python ; coding: utf-8 -*-
"""
MedAI PyInstaller Spec File
Builds a standalone .exe with all dependencies bundled.
"""

import os
import sys

block_cipher = None

# Get the project root
ROOT = os.path.dirname(os.path.abspath(SPEC))

a = Analysis(
    [os.path.join(ROOT, 'main.py')],
    pathex=[ROOT],
    binaries=[],
    datas=[
        # Include data directories
        (os.path.join(ROOT, 'assets'), 'assets'),
        (os.path.join(ROOT, 'auth', 'client_secret.json.template'), os.path.join('auth')),
    ],
    hiddenimports=[
        'customtkinter',
        'PIL',
        'PIL._tkinter_finder',
        'requests',
        'google.auth',
        'google_auth_oauthlib',
        'googleapiclient',
        'ollama',
        'cryptography',
        'sqlite3',
        'json',
        'hashlib',
        'secrets',
        'threading',
        'webbrowser',
        'http.server',
        'tkinter',
        'tkinter.ttk',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'matplotlib', 'numpy', 'pandas', 'scipy', 'IPython',
        'jupyter', 'notebook', 'pytest', 'sphinx',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='MedAI',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,  # No console window — GUI only
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=os.path.join(ROOT, 'assets', 'icon.ico') if os.path.exists(os.path.join(ROOT, 'assets', 'icon.ico')) else None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='MedAI',
)
