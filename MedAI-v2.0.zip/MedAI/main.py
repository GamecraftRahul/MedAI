"""
╔══════════════════════════════════════════════════════════════════╗
║                    MedAI — Medical Intelligence                 ║
║              Your AI-Powered Medical Knowledge Assistant         ║
║                                                                  ║
║  Features:                                                       ║
║    • Comprehensive medical knowledge across all specialties      ║
║    • Google OAuth authentication                                 ║
║    • Chat history saved per user                                 ║
║    • Online mode (full Ollama AI) & Offline mode                 ║
║    • Downloadable medical sub-field data                         ║
║    • Beautiful local GUI (CustomTkinter)                         ║
║                                                                  ║
║  Powered by Ollama · Local AI · Your Data Stays Private          ║
╚══════════════════════════════════════════════════════════════════╝
"""
import sys
import os

# Ensure the project root is in the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def main():
    print("=" * 60)
    print("  🏥 MedAI — Medical Intelligence Assistant")
    print("  Starting application...")
    print("=" * 60)

    # Pre-flight checks
    try:
        import customtkinter
        print("  ✅ CustomTkinter loaded")
    except ImportError:
        print("  ❌ CustomTkinter not found. Run: pip install customtkinter")
        sys.exit(1)

    try:
        import requests
        print("  ✅ Requests library loaded")
    except ImportError:
        print("  ❌ Requests not found. Run: pip install requests")
        sys.exit(1)

    # Check Ollama
    try:
        import requests as req
        r = req.get("http://localhost:11434/api/tags", timeout=3)
        if r.status_code == 200:
            models = [m["name"] for m in r.json().get("models", [])]
            print(f"  ✅ Ollama connected — {len(models)} model(s) available")
            if models:
                print(f"     Models: {', '.join(models[:5])}")
        else:
            print("  ⚠️  Ollama responded but may have issues")
    except Exception:
        print("  ⚠️  Ollama not running — start with: ollama serve")
        print("     (App will work in limited mode)")

    # Check Google OAuth config (optional feature)
    from config import GOOGLE_CLIENT_SECRETS
    if GOOGLE_CLIENT_SECRETS.exists():
        print("  ✅ Google OAuth credentials found")
    else:
        print("  ✅ Using local login system (Google Sign-In is optional)")

    print("=" * 60)
    print("  Launching GUI...")
    print()

    # Launch the app
    from gui.app import MedAIApp
    app = MedAIApp()
    app.mainloop()


if __name__ == "__main__":
    main()
